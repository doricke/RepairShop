
import java.util.Vector;

// import DnaAlignMany;
// import FastaSequence;
// import InputTools;
// import OutputTools;


/******************************************************************************/

public class DnaMSA extends Object
{


/******************************************************************************/

  final static int MAX_SEQUENCES = 9;


/******************************************************************************/

// Matched Sequence Families file.
// private  OutputTools  family_file = new OutputTools ();


/******************************************************************************/

  String [] sequences = null;			// array of sequences

  Vector seq_vector = new Vector ();		// stack of FASTA sequences


/******************************************************************************/
public DnaMSA ()
{
  initialize ();
}  // constructor DnaMSA


/******************************************************************************/
private void initialize ()
{
}  // method initialize


/******************************************************************************/
public void close ()
{
  // family_file.closeFile ();
}  // method close


/*******************************************************************************/
  private void addFasta ( FastaSequence fasta_sequence )
  {
    seq_vector.add ( fasta_sequence );
  }  // method addFasta


/*******************************************************************************/
  private void msa_align ()
  {
    // Set up the array of sequences.
    sequences = new String [ seq_vector.size () ];

    for ( int i = 0; i < seq_vector.size (); i++ )

      sequences [ i ] = ( (FastaSequence) seq_vector.elementAt ( i ) ).getSequence ();
    
    DnaAlignMany align_many = new DnaAlignMany ( sequences, (byte) 12 );

    align_many.printAlignment ();
  }  // method msa_align


/*******************************************************************************/
  public void processFile ( String file_name )
  {
    System.out.println ( "Processing: " + file_name );

    // Set up the input file.
    FastaIterator fasta_file = new FastaIterator ( file_name );

    while ( fasta_file.isEndOfFile () == false )
    {
      // Get the next FASTA sequence.
      FastaSequence fasta_sequence = fasta_file.next ();

      // Add the FASTA sequence to the protein families.
      if ( fasta_sequence.getLength () > 0 )

        addFasta ( fasta_sequence );
    }  // while

    // Close file.
    fasta_file.closeFile ();
  }  // method processFile


/******************************************************************************/
  public void processFiles ( String file_name )
  {
    StringBuffer name_line = new StringBuffer ( 80 );	// Current line of the file

    // Get the file name of the list of GeneMark.HMM output files.
    InputTools name_list = new InputTools ();
    name_list.setFileName ( file_name );
    name_list.openFile ();

    // family_file.setFileName ( file_name + ".families" );
    // family_file.openFile ();

    // Process the list of FASTA protein sequences.
    while ( name_list.isEndOfFile () == false )
    {
      // Read the next line from the list of names file.
      name_line = name_list.getLine ();

      if ( name_list.isEndOfFile () == false )
      {
        String name = name_line.toString ().trim ();

        // Process this file
        processFile ( name );
      }  // if
    }  // while

    // Align the multiple sequences. 
    msa_align ();

    // Close the files.
    name_list.closeFile ();
    close ();
  }  // method processFiles


/******************************************************************************/
  private void usage ()
  {
    System.out.println ( "The command line syntax for this program is:" );
    System.out.println ();
    System.out.println ( "java DnaMSA <file.list>" );
    System.out.println ();
    System.out.print   ( "where <file.list> is the file name of the " );
    System.out.println ( "list of protein FASTA file names." );
  }  // method usage


/******************************************************************************/
  public static void main ( String [] args )
  {
    DnaMSA app = new DnaMSA ();

    if ( args.length == 0 )
      app.usage ();
    else
    {
      app.processFiles ( args [ 0 ] );
    }  // else
  }  // method main

}  // class DnaMSA

