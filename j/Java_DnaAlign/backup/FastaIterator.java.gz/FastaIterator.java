
// import FastaSequence;


/******************************************************************************/

public class FastaIterator extends InputTools
{


/******************************************************************************/

  FastaSequence fasta_sequence = null;		// Current FASTA sequence


/******************************************************************************/
public FastaIterator ()
{
  initialize ();
}  // constructor FastaIterator


/******************************************************************************/
public FastaIterator ( String file_name )
{
  initialize ();

  setFileName ( file_name );
  openFile ();
}  // method FastaIterator


/*******************************************************************************/
  public FastaSequence getFastaSequence ()
  {
    return fasta_sequence;
  }  // method getFastaSequence


/*******************************************************************************/
  private String readSequence ()
  {
    StringBuffer sequence = new StringBuffer ( 10000 );

    // Advance past the header line.
    getLine ();		// get the next line

    while ( ( line.length () > 0 ) && ( line.charAt ( 0 ) != '>' ) )
    {
      sequence.append ( line.toString ().trim () );

      getLine ();		// get the next line
    }  // while

    return sequence.toString ();
  }  // method readSequence


/*******************************************************************************/
  public FastaSequence next ()
  {
    fasta_sequence = new FastaSequence ();		// create a new object

    // Check for first or blank line.
    if ( line.length () <= 0 )  getLine ();

    // Parse the header line.
    fasta_sequence.parseHeader ( line.toString () );

    // Read in the sequence.
    fasta_sequence.setSequence ( readSequence () );

    return fasta_sequence;
  }  // method next


/******************************************************************************/

}  // class FastaIterator

