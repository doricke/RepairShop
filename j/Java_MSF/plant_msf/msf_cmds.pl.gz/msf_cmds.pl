#!/usr/bin/perl -w

use strict;

main:
{
  while ( <> )
  {
    chomp;
    my $filename = $_;
    my $outname;
    if ( /.msf/ )
    {
      $outname = $` . ".out";
    }
    else
    {
      $outname = $filename . ".out";
    }  # else

    print ( "java -jar MSF.jar $filename > $outname\n" );
  }  # while
}  # main
