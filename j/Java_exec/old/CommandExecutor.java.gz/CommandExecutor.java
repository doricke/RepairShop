 
import java.io.*;
import java.util.Vector;
 
public class CommandExecutor
{
   // Data fields
   String cmd;
   int redirectOutput;
   int redirectInput;
   String outFileName;
   String inFileName;
   Process exeProcess;
   InputStream inStr;
   OutputStream outStr;
   InputStream errStr;
   PrintWriter pw;
   BufferedReader br;

/***********************************************************************/
   // Constructor
 
   public CommandExecutor()
   {
      cmd = new String();
   } // end of constructor
/***********************************************************************/
   // Methods
 
// Other methods here...
 
/***********************************************************************/
 
   public StringBuffer execute_blast 
      ( String querySeq
      , String blastDB
      , String blastType
      , int eValue
      , int bValue
      , int vValue
      ) throws IOException
   {
      // validate passed-in values
      if ((querySeq == null) || (blastType == null))
      {
        return new StringBuffer("Invalid input");
      }
      // initialize local variables
      // specify blast environment variables
      String[] blastEnvironment = 
          { "BLASTDB=/bio/info/rrozen/blast_data", 
            "BLASTMAT=/bio/info/rrozen/blast_data" };

      // set up the blast command (number of command line tokens)
      Vector blastCommand = new Vector();
      blastCommand.addElement("/usr/local/bin/blastall");
      blastCommand.addElement("-p");
      blastCommand.addElement(blastType);

      if (blastDB != null)
      {
        blastCommand.addElement("-d");
        blastCommand.addElement(blastDB);
      }
      if (eValue > 0)
      {
        blastCommand.addElement("-e");
        blastCommand.addElement(Integer.toString(eValue));
      }
      if (bValue > 0)
      {
        blastCommand.addElement("-b");
        blastCommand.addElement(Integer.toString(bValue));
      }
      if (vValue > 0)
      {
        blastCommand.addElement("-v");
        blastCommand.addElement(Integer.toString(vValue));
      }
      // FOR BLASTING SSR FLANKS ONLY !!!
      blastCommand.addElement("-F");
      blastCommand.addElement("F");
 
      // initialize the StringBuffer to hold the blast results
      StringBuffer resultBuffer = new StringBuffer();
      // begin executing the subprocess
      String[] blastComArray = new String[blastCommand.size()];
      exeProcess = Runtime.getRuntime().exec(
          (String[])blastCommand.toArray(blastComArray), blastEnvironment);

      BufferedInputStream biStr = 
          new BufferedInputStream(exeProcess.getInputStream());
      PrintStream prStr = new PrintStream(exeProcess.getOutputStream());
      //errStr = exeProcess.getErrorStream();
      prStr.println(querySeq);
      prStr.flush();
      prStr.close();
      //try { exeProcess.waitFor(); } catch(InterruptedException lex3) {}
      int c = 0;
      int previousc = 0;
      while ((c = biStr.read()) != -1)
      {
        resultBuffer.append((char)c);
        if ((previousc == 'x') && (c == ':'))
        {
          break;
        }
        else
        {
          previousc = c;
        }
      }
      biStr.close();
      exeProcess.destroy();
      //Runtime.getRuntime().gc();
      return resultBuffer;
   }
 
/***********************************************************************/
 
   public void execute_formatdb (String[] formatCommand)
   {
      System.out.println ( "execute_formatdb called" );

      // specify blast environment variables
      String[] blastEnvironment = {"BLASTDB=/bio/info/rrozen/blast_data", 
          "BLASTMAT=/bio/info/rrozen/blast_data"};

      try
      {
         exeProcess = Runtime.getRuntime().exec ( "mv a b" );

         exeProcess = Runtime.getRuntime().exec
             (formatCommand, blastEnvironment);
      }  // try
      catch ( IOException e )
      {
        System.out.println ( "execute_formatdb.IOException: " + e );
      }  // catch
   } // end of method execute_formatdb

 
/***********************************************************************/
 
   public synchronized boolean execute_cp (String incommingCommand)
   {
      // initialize local variables
      boolean commandSucceeded = true;
      int exitStatus = 0;
      try
      {
        // begin executing the subprocess
        cmd = incommingCommand;
        exeProcess = Runtime.getRuntime().exec(cmd);
        inStr = exeProcess.getInputStream();
        errStr = exeProcess.getErrorStream();
        exeProcess.waitFor();
        exitStatus = exeProcess.exitValue();
        if (exitStatus > 0)
        {
          commandSucceeded = false;
        }
        exeProcess.destroy();
        Runtime.getRuntime().gc();
      }
      catch(InterruptedException lex1) { commandSucceeded = false; }
      catch(IOException lex2) { commandSucceeded = false; }
 
      return commandSucceeded;
   } // end of method execute

 
/***********************************************************************/
public static void main ( String [] args )
{
  CommandExecutor app = new CommandExecutor ();

  Vector cmds = new Vector ();
  cmds.addElement ( "mv" );
  cmds.addElement ( "c" );
  cmds.addElement ( "d" );

  String [] cmd = new String [ cmds.size () ];
  // cmd = (String[]) cmds.toArray ();
  cmd = (String[]) cmds.toArray ( cmd );
  app.execute_formatdb ( cmd );
}  // method main

 
/***********************************************************************/
} //end of class CommandExecutor
