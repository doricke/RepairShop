
public class Lock
{

  private StringBuffer sb = new StringBuffer ();

  public void getLock ()
  {
    synchronized ( sb )
    {
      try
      {
        sb.wait ();
      }  // try
      catch ( Exception e )
      {
        System.out.println ( "getLock: " + e );
      }  // catch
    }  // synchronized
  }  // method getLock

  public void freeLock ()
  {
    synchronized ( sb )
    {
      sb.notify ();
    }  // synchronized
  }  // method freeLock

}  // class Lock

