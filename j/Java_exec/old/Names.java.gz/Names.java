
import java.util.Vector;


/******************************************************************************/
public class Names
{
  private Vector names = null;

  private Vector active = new Vector ();

  private Vector completed = new Vector ();


/******************************************************************************/
  public Names ()
  {
  }  // constructor Names 

 
/******************************************************************************/
  public synchronized String getNextName ()
  {
    if ( names == null )  return "";

    if ( names.size () <= 0 )  
    {
      System.exit ( 0 );
      return "";
    }  // if

    String name = (String) names.elementAt ( 0 );
    names.removeElementAt ( 0 );
    active.add ( name );
    return name;
  }  // method getNextName


/******************************************************************************/
  public synchronized void failed ( String name )
  {
    System.out.println ( "Names.failed: " + name );
    names.add ( name );
  }  // method failed


/******************************************************************************/
  public synchronized void finished ( String name )
  {
    System.out.println ( "Names.finished: " + name );
    active.remove ( name );
    completed.add ( name );
  }  // method finished


/******************************************************************************/
  public void setNames ( Vector values )
  {
    names = values;
  }  // method setNames

}  // class Names
