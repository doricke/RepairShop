
import java.io.*;

import Names;


/******************************************************************************/
public class SimpleThread extends Thread
{
  private int completed = 0;			// Number of completed jobs

  private String database_name = "Myriad_V8";	// Database name to search

  private Names names = null;			// Source of file names

  private int number_of_cpus = 2;		// Number of CPUs to use

  private String path_name = "";		// Input file path location

  private int problems = 0;			// Number of problem jobs

  private String program_name = "blastn";	// Program name to use

  private boolean success = true;		// Status flag


/******************************************************************************/
  public SimpleThread 
      ( String  thread_name
      , int     cpu_number_of
      , String  name_program
      , String  name_database
      , String  path
      , Names   name_list 
      )
  {
    // Set the name of the thread for display purposes.
    setName ( thread_name );
    // System.out.println ( thread_name + " has been created" );

    number_of_cpus = cpu_number_of;
    program_name   = name_program;
    database_name  = name_database;
    path_name      = path;
    names          = name_list;
  }  // constructor SimpleThread


/******************************************************************************/
  private void sleepy ()
  {
    try 
    {
      // System.out.println ( getName () + " is going to sleep..." );
      // Tell this thread to go to sleep for 300 milliseconds.
      sleep ( 300 );
    }  // try
    catch ( InterruptedException e )
    {
      System.out.println ( "SimpleThread.run: " + e );
    }  // catch

    // System.out.println ( getName () + " woke up from sleep" );
  }  // method sleepy


/******************************************************************************/
  private void drain ( BufferedReader in )
  {
    try
    {
      while ( in.ready () == true )
      {
        String line = in.readLine ();
  
        if ( line.length () > 0 )
        {
          System.out.println ( getName () + " drain: " + line );

          if ( line.indexOf ( "FATAL ERROR" ) >= 0 )
          {
            problems++;
            success = false;
          }  // if
        }  // if
      }  // while
    }  // try
    catch ( IOException e )
    {
      System.out.println ( "drain error: " + e );
    }  // catch
  }  // method drain


/******************************************************************************/
  // Override Thread class run method to get the work done
  public void run ()
  {
    // Do the thread work here
    // System.out.println ( getName () + " entered run method" );

    Process exeProcess = null;
    Runtime runtime = Runtime.getRuntime ();

    String name = "";
    do
    {
      name = names.getNextName ();

      if ( name.length () > 0 )
      {
        // System.out.println ( getName () + " got " + name );
        String command  
            = "rsh " 
            + getName () 
            + " blastall -p " 
            + program_name 
            + " -d "
            + database_name 
            + " -i " 
            + path_name 
            + name 
            + " -a "
            + number_of_cpus
            + " -F F"
            + " -o " 
            + path_name 
            + name 
            + "_-"
            + program_name
            ;

        System.out.println ( command );

        try
        {
          exeProcess = runtime.exec ( command );
          success = true;
        }
        catch ( IOException e )
        {
          System.out.println ( "exeProcess error: " + e );
          success = false;
        }  // catch

        try
        {
          int exit_value = exeProcess.waitFor ();

          if ( exit_value != 0 )
          {
            problems++;
            System.out.println ( "Abnormal exit value: " + exit_value );
            success = false;
          }  // if
          else
          {
            completed++;
            success = true;
          }  // else
        }
        catch ( InterruptedException e )
        {
          System.out.println ( "exeProcess error: " + e );
        }  // catch

        if ( exeProcess != null )
        {
          // Consume the standard err results.
          BufferedReader std_err = new BufferedReader ( new InputStreamReader ( exeProcess.getErrorStream () ) );
          drain ( std_err );
          try
          {
            std_err.close ();
          }  // try
          catch ( IOException e )
          {
            System.out.println ( "std_err close error: " + e );
          }  // catch

          // Consume the standard output results.
          BufferedReader std_out = new BufferedReader ( new InputStreamReader ( exeProcess.getInputStream () ) );
          drain ( std_out );
          try
          {
            std_out.close ();
          }  // try
          catch ( IOException e )
          {
            System.out.println ( "std_out close error: " + e );
          }  // catch
        }  // if

        if ( success == true )
          names.finished ( name );
        else
          names.failed ( name );

        success = true;

        // sleepy ();	// give the other threads a chance
      }  // if
    }
    while ( ( name.length () > 0 ) && ( problems <= 5 ) );

    System.out.print ( getName () + " is done: " );
    if ( problems > 0 )
      System.out.print ( " problems " + problems );
    System.out.println ( " completed " + completed );
  }  // method run


/******************************************************************************/

}  // class SimpleThread

