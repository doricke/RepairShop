
import java.util.Vector;

import InputTools;
import RemoteCoordinator;


/******************************************************************************/
public class ThreadMaster
{


/******************************************************************************/
  private static String [] getCPUNames ()
  {
    String [] names = { "ares", "hades", "hestia", "demeter", "apollo" };
    return names;
  }  // method getCPUNames


/******************************************************************************/
  private static Vector readNames ( String file_name )
  {
    InputTools names_file = new InputTools ();
    names_file.setFileName ( file_name );
    names_file.openFile ();

    Vector all_names = new Vector ();

    // Read in the list of names.
    while ( names_file.isEndOfFile () == false )
    {
      StringBuffer line = names_file.getLine ();

      // Check for a valid name.
      if ( line.length () > 0 )

        // Add the name to the vector.
        all_names.add ( line.toString () );
    }  // while

    names_file.closeFile ();
    names_file = null;

    return all_names;
  }  // method readNames


/******************************************************************************/
  public static void main ( String [] args )
  {
    String [] cpu_names = getCPUNames ();

    int number_of_cpus = 2;

    String path = "/bio/work/ricke/rsh_test/";

    String program_name = "tblastn";

    String database_name = "Myriad_V8";

    RemoteCoordinator [] threads = new RemoteCoordinator [ cpu_names.length ];

    Vector name_list = readNames ( "test.in" );

    Names names = new Names ();
    names.setNames ( name_list );

    for ( int i = 0; i < cpu_names.length; i++ )
    
      threads [ i ] = new RemoteCoordinator 
                              ( cpu_names [ i ]
                              , number_of_cpus
                              , program_name
                              , database_name
                              , path
                              , path
                              , names 
                              );

    for ( int i = 0; i < cpu_names.length; i++ )

      threads [ i ].start ();
  }  // method main


/******************************************************************************/

}  // class ThreadMaster

