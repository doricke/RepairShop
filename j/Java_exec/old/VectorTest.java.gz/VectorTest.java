
import java.util.Vector;

public class VectorTest
{

  public static void main ( String [] args )
  {
    Vector vec = new Vector ();
    vec.add ( "first" );
    vec.add ( "second" );
    vec.add ( "third" );

    while ( vec.size () > 0 )
    {
      String name = (String) vec.elementAt ( 0 );
      System.out.println ( "found " + name );
      vec.removeElementAt ( 0 );
    }
  }  // method main

}  // class VectorTest

