

/******************************************************************************/
public class Timer extends Thread 
{
  private String server_name = "";		// Compute server name


/******************************************************************************/
  public Timer ( String compute_server_name )
  {
    // Set the name of the thread for display purposes.
    setName ( compute_server_name );

    server_name = compute_server_name;
  }  // constructor Timer


/******************************************************************************/
  public void startTimer () throws Exception
  {
    try
    {
      sleep ( 5000 );		// 5 minutes of sleep ???
    }  // try
    catch ( InterruptedException e )
    {
      System.out.println ( "Timer interrupted: " + e );
      return;
    }  // catch

    System.out.println ( "Timer went off for " + server_name + " !!!" );

    Exception your_dead = new Exception ( "Time Limit Exceeded - Your Dead!" );

    throw your_dead;
  }  // method startTimer


/******************************************************************************/
  // Override Thread class run method to get the work done
  public void run () 
  {
    try
    {
      startTimer ();
    }  // try
    catch ( Exception e )
    {
      throw e;
    }  // catch
  }  // method run


/******************************************************************************/

}  // class Timer

