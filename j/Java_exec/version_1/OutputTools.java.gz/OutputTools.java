import java.io.*;
// import java.util.*;


/******************************************************************************/
public class OutputTools extends Object
{

/******************************************************************************/

private String fileName = "";			// Current file name

private int lines_written = 0;			// number of lines written to file

private FileOutputStream output_file = null;	// Output file stream

private PrintStream output_data = null;		// Output print stream


/******************************************************************************/
public OutputTools ()
{
  initialize ();
}  // constructor OutputTools 


/******************************************************************************/
public OutputTools ( String filename )
{
  initialize ();

  setFileName ( filename );
}  // constructor OutputTools


/******************************************************************************/
public String getFileName ()
{
  return fileName;
}  // method getFileName


/******************************************************************************/
  public int getLinesWritten ()
  {
    return lines_written;
  }  // method getLinesWritten


/******************************************************************************/
public PrintStream getPrintStream ()
{ 
  return output_data;
}  // method getPrintStream


/******************************************************************************/
public void setFileName ( String filename )
{
  fileName = filename;
}  // method setFileName 


/******************************************************************************/
public void initialize ()
{
  fileName = "";
  lines_written = 0;
  output_file = null;
  output_data = null;
}  // method initialize 



/******************************************************************************/
public void openFile ()
{
  try
  {
    output_file = new FileOutputStream ( fileName );

    output_data = new PrintStream ( output_file );
  }  /* try */
  catch ( IOException e )
  {
    System.out.println ( "OutputTools.openFile: IOException on output file: " 
        + fileName + "; " + e );
  }  /* catch */

}  // method openFile 


/******************************************************************************/
public void closeFile ()
{
  if ( output_data != null )
  {
    output_data.flush ();
    output_data.close ();
  }  // if

  try
  {
    if ( output_file != null )
      output_file.close ();
  }
  catch ( IOException e )
  {
    System.out.println ( "close: " + e );
  }  // catch
}  // method closeFile 


/******************************************************************************/
public void deleteFile ()
{
  closeFile ();

  File delete_file = new File ( fileName );

  delete_file.deleteOnExit ();
  delete_file = null;
  output_file = null;
  output_data = null;
}  // method deleteFile


/******************************************************************************/
public void flushFile ()
{
  if ( output_data != null )
  
    output_data.flush ();
}  // method flushFile


/******************************************************************************/
public void print ( String text_string )
{
  output_data.print ( text_string );
}  // method print


/******************************************************************************/
public void println ()
{
  output_data.println ();
  lines_written++;
}  // method println


/******************************************************************************/
public void println ( String line )
{
  output_data.println ( line );
  lines_written++;
}  // method println


/******************************************************************************/
public void println ( StringBuffer line )
{
  output_data.println ( line.toString () );
  lines_written++;
}  // method println


/******************************************************************************/
  public static void write ( String name, char value )
  {
    if ( value != ' ' )
      System.out.println ( name + " = " + value );
  }  // method write


/******************************************************************************/
  public static void write ( String name, int value )
  {
    if ( value != 0 )
      System.out.println ( name + " = " + value );
  }  // method write


/******************************************************************************/
  public static void write ( String name, String value )
  {
    if ( value.length () > 0 )
      System.out.println ( name + "\t" + value );
  }  // method write


/******************************************************************************/
public static void main ( String [] args )
{
  OutputTools app = new OutputTools ();

  app.setFileName ( "test.out" );

  app.openFile ();

  app.println ( "test" );

  app.closeFile ();
}  // method main 

}  // class OutputTools 
