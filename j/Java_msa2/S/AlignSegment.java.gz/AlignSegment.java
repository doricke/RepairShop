
public class AlignSegment extends Object
{

/******************************************************************************/

  int start_1;				// Start of alignment in sequence 1

  int start_2;				// Start of alignment in sequence 2

  int end_1;				// End of alignment in sequence 1

  int end_2;				// End of alignment in sequence 2


/******************************************************************************/
public AlignSegment ()
{
  initialize ();
}  // constructor AlignSegment


/******************************************************************************/
public void initialize ()
{
  start_1 = -1;
  start_2 = -1;
  end_1 = -1;
  end_2 = -2;
}  // method initialize


/******************************************************************************/
public int getEnd1 ()
{
  return end_1;
}  // method getEnd1


/******************************************************************************/
public int getEnd2 ()
{
  return end_2;
}  // method getEnd2


/******************************************************************************/
public int getStart1 ()
{
  return start_1;
}  // method getStart1


/******************************************************************************/
public int getStart2 ()
{
  return start_2;
}  // method getStart2


/******************************************************************************/
public void setEnd1 ( int end1 )
{
  end_1 = end1;
}  // method setEnd1


/******************************************************************************/
public void setEnd2 ( int end2 )
{
  end_2 = end2;
}  // method setEnd2


/******************************************************************************/
public void setStart1 ( int start1 )
{
  start_1 = start1;
}  // method setStart1


/******************************************************************************/
public void setStart2 ( int start2 )
{
  start_2 = start2;
}  // method setStart2


/******************************************************************************/

}  // class AlignSegment
