import InputTools;


/******************************************************************************/
public class Alignment extends Object
{


/******************************************************************************/

private StringBuffer accession = new StringBuffer ( 20 );	// Accession identifier

private StringBuffer description = new StringBuffer ( 128 );	// Description line

private int gaps = 0;						// Number of gaps

private int good_start = 0;					// Start of good alignment

private int good_end = 0;					// End of good alignment

private int identities = 0;					// Number of identities

private StringBuffer line = new StringBuffer ( 128 );		// Current line

private StringBuffer query = new StringBuffer ( 10000 );	// Query sequence

private StringBuffer query_name = new StringBuffer ( 60 );	// Query name

private int query_start = 0;					// Query start start 

private StringBuffer score = new StringBuffer ( 20 );		// Score

private StringBuffer target = new StringBuffer ( 10000 );	// Target sequence

private StringBuffer target_name = new StringBuffer ( 60 );	// Target name

private int target_start = 0;					// Target sequence start


private InputTools tl_file;					// TimeLogic input file

/******************************************************************************/

// Parameters that affect algorithms.

private int min_identities = 24;		// Minimum number of Identities

private int min_local_identities = 7;		// Minimum number of identities in a 10 bp window

private int min_percent = 40;			// Minimum percent identity


/******************************************************************************/
public Alignment ()
{
  initialize ();
}  /* constructor Alignment */


/******************************************************************************/
public void initialize ()
{
  accession.setLength ( 0 );
  description.setLength ( 0 );
  gaps = 0;
  good_start = 0;
  good_end = 0;
  identities = 0;
  line.setLength ( 0 );
  query.setLength ( 0 );
  query_name.setLength ( 0 );
  query_start = 0;
  score.setLength ( 0 );
  target.setLength ( 0 );
  target_name.setLength ( 0 );
  target_start = 0;
}  // method initialize


/******************************************************************************/
public void close ()
{
  initialize ();
  accession = null;
  description = null;
  line = null;
  query = null;
  query_name = null;
  score = null;
  target = null;
  target_name = null;
  tl_file = null;
}  // close


/******************************************************************************/
private void countIdentities ( int start, int end )
{
  identities = 0;

  for ( int i = start; i <= end; i++ )
  {
    if ( query.charAt ( i ) == target.charAt ( i ) )  identities++;
  }  // for

// System.out.println ( "good_start = " + good_start + ", good_end = " + good_end +
//    ", identities = " + identities );
}  // method countIdentities


/******************************************************************************/
public boolean isGoodAlignment ()
{
  if ( ( identities >= min_identities ) &&
       ( ( identities * 100 ) / (good_end - good_start + 1) >= min_percent ) )
    return true;
  else
    return false;
}  // method isGoodAlignment


/******************************************************************************/
public void setFile ( InputTools input_file )
{
  tl_file = input_file;
}  // method setFile


/******************************************************************************/
public void setMinIdentities ( int minimum_identities )
{
  min_identities = minimum_identities;
}  // method setMinIdentities


/******************************************************************************/
public void setMinLocalIdentities ( int minimum_local_identities )
{
  min_local_identities = minimum_local_identities;
}  // method setMinLocalIdentities


/******************************************************************************/
public void setMinPercent ( int minimum_percent )
{
  min_percent = minimum_percent;
}  // method setMinPercent


/******************************************************************************/
public StringBuffer getAccession ()
{
  return accession;
}  // method getAccession


/******************************************************************************/
public StringBuffer getDescription ()
{
  return description;
}  // method getDescription


/******************************************************************************/
public int getGaps ()
{
  return gaps;
}  // method getGaps


/******************************************************************************/
public int getIdentities ()
{
  return identities;
}  // method getIdentities


/******************************************************************************/
public StringBuffer getQuery ()
{
  return query;
}  // method getQuery


/******************************************************************************/
public StringBuffer getQueryName ()
{
  return query_name;
}  // method getQueryName


/******************************************************************************/
public int getQueryStart ()
{
  return query_start;
}  // method getQueryStart


/******************************************************************************/
public StringBuffer getScore ()
{
  return score;
}  // method getScore


/******************************************************************************/
public StringBuffer getTarget ()
{
  return target;
}  // method getTarget


/******************************************************************************/
public StringBuffer getTargetName ()
{
  return target_name;
}  // method getTargetName


/******************************************************************************/
public int getTargetStart ()
{
  return target_start;
}  // method getTargetStart


/******************************************************************************/
private void processAlignmentHeader ()
{
  int end = 0;

  // Initialize the alignment details.
  initialize ();

  // Find the RANK line. 
  boolean found = false;
  while ( ( tl_file.isEndOfFile () == false ) &&
          ( found == false ) )
  {
    line = tl_file.getLine ();

    // Check for a line with data.
    if ( line.length () > 0 )

      // Check for the RANK line.
      if ( line.toString ().startsWith ( "RANK" ) )  found = true;
  }  // while

  // Process the alignment header. 
  while ( ( tl_file.isEndOfFile () == false ) &&
          ( line.length () > 0 ) &&
          ( line.charAt ( 0 ) != 'Q' ) )
  {
    // Check for a long enough line. 
    if ( line.length () >= 6 )
    {
      // Check for RANK line.
      if ( line.charAt ( 0 ) == 'R' )
      {
        score.append ( line.substring ( 17 ).trim () );
      }    // if

      // Check for Q(uery) name line.
      if ( ( line.charAt ( 1 ) == 'Q' ) && ( line.charAt ( 2 ) == ' ' ) )
      {
        end = line.toString ().indexOf ( " ", 5 );
        query_name.append ( line.substring ( 5, end ) );
      }  // if

      // Check for T(arget) name line.
      if ( line.charAt ( 1 ) == 'T' )
      {
        end = line.toString ().indexOf ( " ", 5 );
        target_name.append ( line.substring ( 5, end ) );
      }  // if

      // Check for A(ccession) name line.
      if ( line.charAt ( 1 ) == 'A' )
      {
        if ( line.length () > 7 )
          accession.append ( line.substring ( 5 ) );
      }  // if

      // Check for D(escription) name line.
      if ( line.charAt ( 1 ) == 'D' )
      {
        description.append ( line.substring ( 5 ) );
      }  // if

      // Check for Identical Match line.
      if ( line.charAt ( 1 ) == 'I' )
      {
        identities = tl_file.getInteger ( line.substring ( 17 ) );

        gaps = tl_file.getInteger ( line.substring ( 46 ) );
      }  // if

      // Check for QS (Query Start) line.
      if ( ( line.charAt ( 1 ) == 'Q' ) && ( line.charAt ( 2 ) == 'S' ) )
      {
        query_start = tl_file.getInteger ( line.substring ( 5 ) );

        target_start = tl_file.getInteger ( line.substring ( 33 ) );
      }  // if
    }  // if 

    // Get the next line.
    line = tl_file.getLine ();
  }  // while
}  // method processAlignmentHeader


/******************************************************************************/
private void findGoodEnd ()
{
  int local_identities = 0;
  int region_start = query.length () - 10;

  // Loop until a good region is found.
  while ( ( local_identities < min_local_identities ) &&
          ( region_start >= 0 ) )
  {
    // Count the local identities.
    local_identities = 0;
    for ( int i = region_start; i < region_start + 10; i++ )

      // Count identities.
      if ( query.charAt ( i ) == target.charAt ( i ) )  local_identities++;

    // Check if need to check a new region
    if ( local_identities < min_local_identities )
    {
      region_start--;
      good_end--;
    }  // if 
  }  // while

  // Trim at mismatched last base.
  while ( ( good_end > 0 ) &&
          ( query.charAt ( good_end ) != target.charAt ( good_end ) ) )

    good_end--;

  // Check if no good regions were found.
  if ( local_identities < min_local_identities )  good_end = 0;
}  // method findGoodEnd


/******************************************************************************/
private void findGoodStart ()
{
  int local_identities = 0;
  int region_start = 0;

  // Loop until a good region is found.
  while ( ( local_identities < min_local_identities ) &&
          ( region_start + 9 < good_end ) )
  {
    // Count the local identities.
    local_identities = 0;
    for ( int i = region_start; i < region_start + 10; i++ )

      // Count identities.
      if ( query.charAt ( i ) == target.charAt ( i ) )  local_identities++;

    // Check if need to check a new region
    if ( local_identities < min_local_identities )
    {
      region_start++;
      good_start++;
    }  // if 
  }  // while

  // Trim at mismatched first base.
  while ( ( good_start < good_end ) &&
          ( query.charAt ( good_start ) != target.charAt ( good_start ) ) )

    good_start++;

  // Check if no good regions were found.
  if ( local_identities < min_local_identities )  good_start = good_end;
}  // method findGoodStart


/******************************************************************************/
private void findGoodRegion ()
{
  // Find the end of a good alignment.
  findGoodEnd ();

  // Find the begining of a good alignment.
  findGoodStart ();
}  // method findGoodRegion


/******************************************************************************/
private void addAlignmentSegment ()
{
  int start;

  // Current line is the Query line.
  if ( line.length () > 10 )
  {
    start = tl_file.getInteger ( line.substring ( 1, 10 ) );

    // Get the query sequence segment.
    query.append ( line.substring ( 10 ) );
  }  // if
  else
    System.out.println ( "Query line expected: " + line.toString () );

  // Get the identities line.
  line = tl_file.getLine ();

  // Get the Target line.
  line = tl_file.getLine ();

  if ( line.length () > 10 )
  {
    start = tl_file.getInteger ( line.substring ( 1, 10 ) );

    // Get the target sequence segment.
    target.append ( line.substring ( 10 ) );
  }  // if
  else
    System.out.println ( "Target line expected: " + line.toString () );
}  // method addAlignmentSegment


/******************************************************************************/
public void processAlignment ()
{
  // Process the alignment header.
  processAlignmentHeader ();

  // Add alignments segments to the alignment.
  boolean end_of_alignment = false;
  while ( ( tl_file.isEndOfFile () == false ) && ( end_of_alignment == false ) )
  {
    // Check for a line with data on it.
    if ( line.length () > 0 )
    {
      // Check for the next alignment segment.
      if ( line.charAt ( 0 ) == 'Q' )

        addAlignmentSegment ();
    }  // if

    // Get the next line of the file.
    line = tl_file.getLine ();

    // Check for a line with data on it.
    if ( line.length () > 0 )

      // Check for the end of alignment line.
      if ( line.charAt ( 0 ) == '_' )  end_of_alignment = true;
  }  // while

  // Set the limits of the good part of the alignment.
  good_start = 0;
  good_end = query.length () - 1;
  findGoodRegion ();

  // Count the identities;
  countIdentities ( good_start, good_end );
}  // method processAlignment


/******************************************************************************/
public void printAlignment ()
{
  System.out.print ( "Q  = " + query_name );
  System.out.println ( "\tQS = " + query_start );
  System.out.print ( "T  = " + target_name );
  System.out.println ( "\tTS = " + target_start );
  System.out.println ();

  for ( int i = good_start; i <= good_end; i += 50 )
  {
    int end = i + 50;
    if ( end > good_end )  end = good_end + 1;

    System.out.print ( query_start + i );
    System.out.print ( "\t" );
    System.out.println ( query.substring ( i, end ) );

    System.out.print ( "\t" );
    for ( int j = i; j < end; j++ )
      if ( query.charAt ( j ) == target.charAt ( j ) )
        System.out.print ( "|" );
      else
        System.out.print ( " " );
    System.out.println ();

    System.out.print ( target_start + i );
    System.out.print ( "\t" );
    System.out.println ( target.substring ( i, end ) );
    System.out.println ();
  }  // for
}  // method printAlignment


/******************************************************************************/

}  /* class Alignment */
