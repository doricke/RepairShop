
public class AminoAcids extends Object
{


/******************************************************************************/

/* overlapping bit specification indicates allowable conservative */
/* substitutions. */
private static final int [] cons_mask = {
    /* A   B  C       D     E     F    G       H       I    J  K      L */
      0x2, 0, 0x1000, 0x30, 0x90, 0x8, 0x2000, 0x4000, 0x1, 0, 0x100, 0x1, 
    /* M     N     O  P        Q     R      S    T    U  V    W        X */
      0x800, 0x60, 0, 0x10000, 0xc0, 0x100, 0x6, 0x4, 0, 0x1, 0x20000, ALL_BITS,
    /* Y   Z */
      0x8, 0 };



/******************************************************************************/
  public

/******************************************************************************/


/******************************************************************************/

}  // class AminoAcids



