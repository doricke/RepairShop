import java.io.*;
import java.sql.*;
import InputTools;
import XMLTools;
import Alignment;
import MSA;


/******************************************************************************/
public class ScanTL extends Object
{


/******************************************************************************/

private String fileName = "";			// Current file name

private StringBuffer sequence = new StringBuffer ( 2000 );	// DNA sequence

private StringBuffer sequenceName = new StringBuffer ( 64 );	// Individual read name


private InputTools tl_file = new InputTools ();	// input file

private StringBuffer line = new StringBuffer ( 128 );	// Current line

private XMLTools xml_file = new XMLTools ();		// XML output file


// Get the current date.
java.sql.Date date = new java.sql.Date ( System.currentTimeMillis () );


/******************************************************************************/
public ScanTL ()
{
  initialize ();
}  /* constructor ScanTL */


/******************************************************************************/
private void initialize ()
{
  line.setLength ( 0 );
  sequence.setLength ( 0 );
  sequenceName.setLength ( 0 );
}  // method initialize


/******************************************************************************/
public void setFileName ( String filename )
{
  fileName = filename;
}  /* method setFileName */


/******************************************************************************/
// Old method
private void readSequence ( StringBuffer seq )
{
  // Clear old sequence.
  seq.setLength ( 0 );

  // Assert that the current line is the first line of the sequence.
  String current_line = line.toString ().trim ();

  // Read in the sequence until the first blank line.
  while ( current_line.length () > 0 )
  {
    // Append the current line to the sequence.
    seq.append ( current_line );

    // Get the next line of the file.
    line = tl_file.getLine ();
    current_line = line.toString ().trim ();
  }  /* while */
}  // method readSequence 


/******************************************************************************/
// Old method
private void writeSequenceClob ( String entry_name, String field_name, String clob )
{
  // Create the SequenceClob XML entry.
  xml_file.write_XML_entry ( entry_name );

  // Create the sequence_clob field.
  xml_file.write_XML_clob_field ( field_name, clob );

  // End the SequenceClob entry.
  xml_file.write_XML_entry_end ();
}  // method writeSequenceClob


/******************************************************************************/
// Old method
private void readContig ()
{
  // Get the first line of the consensus sequence.
  tl_file.getLine ();

  // Complete the last Alignment table entry.
    xml_file.write_XML_entry_end ();

  // Start an alignment.
  xml_file.write_XML_entry ( "Alignment" );

  // Create a Sequence entry for the Contig sequence.
  xml_file.write_XML_entry ( "Sequence" );
  xml_file.write_XML_field ( "sequence_description", "consensus sequence" );
//  xml_file.write_XML_field ( "sequence_length", "" + contig_length );
//  xml_file.write_XML_field ( "sequence_name", contigName.toString () );
  // Set the analysis_date field.
  xml_file.write_XML_field ( "date_created", date.toString (), 
      "format", "yyyy-mm-dd" );

  // End the Sequence table entry.
  xml_file.write_XML_entry_end ();
}  // method readContig 


/******************************************************************************/


/******************************************************************************/


/******************************************************************************/
private void processHeader ()
{
  if ( tl_file.isEndOfFile () == true )
  {
    System.out.println ( "processHeader: end of input file" );
    return;
  }  // if

  // Get the next line.
  line = tl_file.getLine ();
  String current_line = line.toString ();

  // Process the header fields.
  while ( ( tl_file.isEndOfFile () == false ) &&
          ( line.length () > 10 ) )
  {
    if ( current_line.startsWith ( "[MAX SCORES]" ) == true )
      System.out.println ( "MS: " + current_line );

    if ( current_line.startsWith ( "[MAX ALIGNMENTS]" ) == true )
      System.out.println ( "MA: " + current_line );

    // Get the next line.
    line = tl_file.getLine ();
    current_line = line.toString ();
  }  // while
}  // method processHeader


/******************************************************************************/
private void processScores ()
{
  if ( tl_file.isEndOfFile () == true )
  {
    System.out.println ( "processScores: end of input file" );
    return;
  }  // if

  String current_line = line.toString ();

  // Process the header fields.
  while ( ( tl_file.isEndOfFile () == false ) &&
          ( current_line.startsWith ( "[ALIGNMENTS]" ) == false ) )
  {
    // Get the next line.
    line = tl_file.getLine ();
    current_line = line.toString ();
  }  // while
}  // method processScores


/******************************************************************************/
private void processAlignments ()
{
  MSA msa = new MSA ();
  msa.allocateMSA ();

  // Create a new alignment.
  Alignment alignment = new Alignment ();

  // Set up the alignment input file.
  alignment.setFile ( tl_file );

  // Read in the alignments.
  while ( tl_file.isEndOfFile () == false )
  {
    // Read in the next alignment.
    alignment.processAlignment ();

    // Check for a good alignment.
    if ( alignment.isGoodAlignment () == true )
    {
      // Add the pair-wise alignment to the MSA.
      msa.addAlignment ( alignment );

      // Print out the alignment.
      // alignment.printAlignment ();
    }  // if

    // Initialize for the next alignment.
    alignment.initialize ();
  }  // while

  // Add the consensus sequence.
  msa.addConsensus ();

  // Print out the MSA.
  msa.printMSA ();

  // Find close gap characters.
  msa.findCloseGaps ();

  // Find the non-gap characters.
  msa.findNonGaps ();

  // Close the MSA.
  msa.close ();

  // Close the alignment.
  alignment.close ();
  alignment = null;
}  // method processAlignments


/******************************************************************************/
// This method processes the file.
private void processTL ()
{
  // Set the input file name.
  tl_file.setFileName ( fileName );

  // Open the input file.
  tl_file.openFile ();

  // Set the XML file name.
  xml_file.setFileName ( fileName + ".xml" );

  // Open the XML file for writing.
  xml_file.open_XML_file ();

  // Write the XML file header.
  xml_file.write_XML_header ();

  // Process the header block.
  processHeader ();

  // Process the scores block.
  processScores ();

  // Process the alignments.
  processAlignments ();

  // Complete the XML file.
  xml_file.write_XML_footer ();
  xml_file.close_XML ();

  // Close the input file.
  tl_file.closeFile ();

  // Close the XML file.
  xml_file.closeFile ();
}  // method processTL


/******************************************************************************/
public static void usage ()
{
  System.out.println ( "This is the ScanTL program." );
  System.out.println ();
  System.out.println ( "This program converts a TimeLogic Smith-Waterman output file to XML." );
  System.out.println ();
  System.out.println ( "To run type:" );
  System.out.println ();
  System.out.println ( "java ScanTL <name.out>" );
  System.out.println ();
  System.out.println ( "Where <name.out> is a TimeLogic Smith-Waterman output filename." );
  System.out.println ();
  System.out.println ( "The XML output file name will be named name.out.xml" );
}  // method usage


/******************************************************************************/
public static void main ( String [] args )
{
  /* Check for parameters. */
  if ( args.length == 0 )
  {
    usage ();
  }
  else
  {
    ScanTL application = new ScanTL ();

    // The TimeLogic Smith-Waterman output file name is the first parameter.
    application.setFileName ( args [ 0 ] );

    // Process the alignments.
    application.processTL ();
  }  /* else */
}  /* method main */

}  /* class ScanTL */
