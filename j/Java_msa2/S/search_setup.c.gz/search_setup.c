


/* 

	Copyright (c) 1995-1997 The Regents of the University of California

NOTICE: The Government is granted for itself and others acting on its behalf a paid-up, 
non-exclusive, irrevocable worldwide license in this data to reproduce, prepare derivative 
works, and perform publicly and display publicly.  Beginning five (5) years after 4/20/1997,
subject to two possible five year renewals, the Government is granted for itself and others
acting on its behalf a paid-up, non-exclusive, irrevocable worldwide license in this data to
reproduce, prepare derivative works, distribute copies to the public, perform publicly and
display publicly, and to permit others to do so.  NEITHER THE UNITED STATES NOR THE UNITED
STATES DEPARTMENT OF ENERGY, NOR ANY OF THEIR EMPLOYEES, MAKES ANY WARRANTY, EXPRESS OR
IMPLIED, OR ASSUMES ANY LEGAL LIABILITY OR RESPONSIBILITY FOR THE ACCURACY, COMPLETENESS,
OR USEFULNESS OF ANY INFORMATION, APPARATUS, PRODUCT, OR PROCESS DISCLOSED, OR REPRESESENTS
THAT ITS USE WOULD NOT INFRINGE PRIVATELY OWNED RIGHTS.

*/




#include <stdio.h>
#include <signal.h>




#define  TRUE		1
#define  FALSE		0

#define  DNA		0
#define  PROTEIN	1

#define  BLOCK_SIZE	60	/* output block size */

#define  CODON_SIZE     3	/* number of bases in DNA codon */


#define  BLAST_PROGRAMS 3	/* number of BLAST programs to search with */

#define  FASTA_PROGRAMS 2	/* number of FASTA programs (1 DNA & same for protein) */

#define  PROTEIN_DATABASES 3	/* number of protein databases */

				/* "EGHPRSU" */
#define  DNA_LIBRARIES  8	/* dbEST, GenBank, GenPepet, PIR, Repeats, Swiss, GBCU, */
				/* fugu, cs16p13, c16exons */

#define  MAX_ASCII      256     /* maximum ASCII characters */

#define  MAX_BASES      550000  /* maximum DNA sequence length */

#define  MAX_CODON	64	/* number of codons */

#define  MAX_DATABASES  8	/* current upper limit on databases to search */

#define  MAX_LINE	1012	/* maximum line length */

#define  MIN_SEQ	12	/* minimum sequence length */

#define  MAX_TLC	8	/* maximum number of files to Time Logic Computer */



/* DNA sequence. */
typedef  struct {
  long  total;			/* sequence length */
  char  name [ MAX_LINE ];	/* file name */
  char  base [ MAX_BASES ];	/* DNA bases */
} t_seq;


/* Text file. */
typedef struct {
  char  name [ MAX_LINE ];	/* file name */
  char  next;			/* current character */
  char  token [ MAX_LINE ];	/* current token */
  char  line  [ MAX_LINE ];	/* current line */
  int   line_index;		/* line index */
  FILE  *data;			/* data file */
  short eof;			/* end of file flag */
} t_text;


static  int  base_map [ 123 ] = { 0,

/* 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 */
  70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,64,70,70,70,70,70,70,70,70,

/*26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 */
  70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,64,70,70,70,70,70,70,70,70,

/* 51  52  53  54  55  56  57  58  59  60  61  62  63  64 */
   64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,

/* A   B  C   D   E   F  G   H   I   J   K   L   M */  
   2, 64, 1, 64, 64, 64, 3, 64, 64, 64, 64, 64, 64, 

/* N   O   P   Q   R   S  T  U   V   W   X   Y   Z */
  64, 64, 64, 64, 64, 64, 0, 0, 64, 64, 64, 64, 64,

  64, 64, 64, 64, 64, 64,

/* a   b  c   d   e   f  g   h   i   j   k   l   m */  
   2, 64, 1, 64, 64, 64, 3, 64, 64, 64, 64, 64, 64, 

/* n   o   p   q   r   s  t  u   v   w   x   y   z */
  64, 64, 64, 64, 64, 64, 0, 0, 64, 64, 64, 64, 64
};


static  int  base_map_3 [ 123 ] = { 0,

/* 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 */
  70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,64,70,70,70,70,70,70,70,70,

/*26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 */
  70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,70,64,70,70,70,70,70,70,70,70,

/* 51  52  53  54  55  56  57  58  59  60  61  62  63  64 */
   64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,

/* A   B  C   D   E   F  G   H   I   J   K   L   M */  
   2, 64, 1, 64, 64, 64, 3, 64, 64, 64, 64, 64, 64, 

/* N   O   P   Q   R   S  T  U   V   W   X   Y   Z */
  64, 64, 64, 64,  2, 64, 0, 0, 64, 64, 64,  0, 64,

  64, 64, 64, 64, 64, 64,

/* a   b  c   d   e   f  g   h   i   j   k   l   m */  
   2, 64, 1, 64, 64, 64, 3, 64, 64, 64, 64, 64, 64, 

/* n   o   p   q   r   s  t  u   v   w   x   y   z */
  64, 64, 64, 64,  2, 64, 0, 0, 64, 64, 64,  0, 64
};


/* Genetic code */
static  char  codon_map [ 64 ] = {
  'F', 'F', 'L', 'L',     'S', 'S', 'S', 'S',  
  'Y', 'Y', 'X', 'X',     'C', 'C', 'X', 'W',

  'L', 'L', 'L', 'L',     'P', 'P', 'P', 'P',
  'H', 'H', 'Q', 'Q',     'R', 'R', 'R', 'R',

  'I', 'I', 'I', 'M',     'T', 'T', 'T', 'T',
  'N', 'N', 'K', 'K',     'S', 'S', 'R', 'R',

  'V', 'V', 'V', 'V',     'A', 'A', 'A', 'A',
  'D', 'D', 'E', 'E',     'G', 'G', 'G', 'G'  };


static  char  complement [ 123 ] = {

/*    1    2    3    4    5    6    7    8    9   10 */
' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
     ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  /* 20 */
     ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  /* 30 */
     ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  /* 40 */
     ' ', ' ', ' ', ' ', '-', '.', ' ', ' ', ' ', ' ',  /* 50 */
     ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',  /* 60 */
     ' ', ' ', ' ', ' ',                                /* 64 */

/*  a    b    c    d    e    f    g    h    i    j    k    l    m */
   'T', 'V', 'G', 'H', ' ', ' ', 'C', 'D', ' ', ' ', 'M', ' ', 'K',

/*  n    o    p    q    r    s    t    u    v    w    x    y    z */
   'N', ' ', ' ', ' ', 'Y', 'S', 'A', 'A', 'B', 'W', 'N', 'R', ' ',

   ' ', ' ', ' ', ' ', ' ', ' ',

/*  a    b    c    d    e    f    g    h    i    j    k    l    m */
   't', 'v', 'g', 'h', ' ', ' ', 'c', 'd', ' ', ' ', 'm', ' ', 'k',

/*  n    o    p    q    r    s    t    u    v    w    x    y    z */
   'n', ' ', ' ', ' ', 'y', 's', 'a', 'a', 'b', 'w', 'n', 'r', ' '
};


static  int  dna_mask [ 123 ] = { 0,

/*    1    2    3    4    5    6    7    8    9   10 */
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  /* 20 */
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  /* 30 */
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  /* 40 */
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  /* 50 */
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,  /* 60 */
      0,   0,   0,   0,   

/*  a    b    c    d    e    f    g    h    i    j    k    l    m */
    1, 0xE,   4, 0xB,   0,   0,   2, 0xD,   0,   0, 0xA,   0,   5,

/*  n    o    p    q    r    s    t    u    v    w    x    y    z */
  0xF,   0,   0,   0,   3,   6,   8,   8,   7,   9, 0xF, 0xC,   0,

    0,   0,   0,   0,   0,   0,

/*  a    b    c    d    e    f    g    h    i    j    k    l    m */
    1, 0xE,   4, 0xB,   0,   0,   2, 0xD,   0,   0, 0xA,   0,   5,

/*  n    o    p    q    r    s    t    u    v    w    x    y    z */
  0xF,   0,   0,   0,   3,   6,   8,   8,   7,   9, 0xF, 0xC,   0 };


/* List of database names. */
static  char  *database [] = {
  "Swiss", "PIR", "GenPept", 						/* protein databases */
  "repeats", "gbcu", "gbest", "genbank", "gbpln", "self", "cs16p13", "c16exons" };	/* DNA databases */

/* List of database letters. */
static  char  *database_letter [] = {
  "S", "P", "T", 					/* protein databases */
  "R", "U", "E", "G", "F", "L", "C", "X" };		/* DNA databases */

/* List of blast search programs. */
static  char  *blast_program [] = { "blastx", "blastn", "tblastx" };

/* List of blast search programs' suffixes. */
static  char  *blast_suffix [] = { "x", "n", "t" };



main ( argc, argv )
int argc;		/* number of command line arguments */
char *argv [];		/* command line arguments */
{
  t_text  cmds;				/* file of BLAST and FAsta search commands */
  int     database_index;		/* current database index */
  int     database_limit;		/* upper limit on database index */
  t_text  erase;			/* Unix erase shell commands */
  t_text  library;			/* FASTA-style library of DNA sequences */
  char    make_sub [ MAX_LINE ];	/* command to make subdirectory */
  t_text  names;			/* file of sequence names file */
  int     program_index;		/* blast program index */
  char    scr_name [ MAX_LINE ];	/* scratch path name */
  t_text  sub_erase;			/* Searches subdirectory erase commands */
  t_text  sub_list;			/* Searches subdirectory list of searches */
  char    sub_list_name [ MAX_LINE ];	/* Searches subdirectory list file name */
  char    sub_name [ MAX_LINE ];	/* Searches output subdirectory name */


  /* Issue the Copyright notice. */
  copyright ();

  printf ( "Program: Quick_Search for fasta vector and repeat identification.\n\n" );

  printf ( "This is the Sequence files --> BLAST & Fasta searches program (Version 1.0).\n\n" );

  /* Check for command line parameters. */
  if ( argc > 1 )
  {
    /* Assume the first parameter is the file name of the list of sequences to process. */
    strcpy ( names.name, argv [ 1 ] );
    open_text_file ( &names );
  }
  else

    /* Prompt for the input file name. */
    prompt_file ( &names, "What is the list of sequences file name?" );

  /* Create the searches directory name. */
  change_suffix ( names.name, "Searches", sub_name );
  strcpy ( make_sub, "mkdir " );
  d_strcat ( make_sub, sub_name );
  d_system ( make_sub );

  printf ( "This version writes search results to %s\n\n", sub_name );

  /* Open the commands file. */
  strcpy ( erase.name, "erase" );
  erase.data = fopen ( erase.name, "w" );

  /* Create the Searches erase file. */
  change_suffix ( names.name, "erase", scr_name );
  strcpy ( sub_erase.name, sub_name );
  d_strcat ( sub_erase.name, "/" );
  d_strcat ( sub_erase.name, scr_name );
  sub_erase.data = fopen ( sub_erase.name, "w" );

  /* Create the Searches list file. */
  change_suffix ( names.name, "lis", sub_list_name );
  strcpy ( sub_list.name, sub_name );
  d_strcat ( sub_list.name, "/" );
  d_strcat ( sub_list.name, sub_list_name );
  sub_list.data = fopen ( sub_list.name, "w" );

  /* Copy all of the DNA sequences into a FASTA-formated library. */
  make_fasta_library ( &library, &erase, &names );

  /* Open the commands file. */
  change_suffix ( names.name, "cmds", cmds.name );
  cmds.data = fopen ( cmds.name, "w" );

  /* Set up BLAST search files. */
  for ( program_index = 0; program_index < BLAST_PROGRAMS; program_index++ )
  {
    if ( program_index == 0 )
    {
      database_index = 0;
      database_limit = PROTEIN_DATABASES;
    }  /* if */
    else
    {
      database_index = PROTEIN_DATABASES;
      database_limit = MAX_DATABASES;
    }  /* if */

    for ( ; database_index < database_limit; database_index++ )

      /* Search the database with the specified blast program. */
      blast_main ( program_index, database_index, &cmds, &erase, &names, sub_name, &sub_list, &sub_erase );
  }  /* for */

printf ( "befre fasta_main loop\n" );

  for ( database_index = 0; database_index <= MAX_DATABASES; database_index++ )

      /* Search the database with the specified FASTA program. */
      fasta_main ( database_index, &cmds, &erase, &names, library.name, sub_name, &sub_list, &sub_erase );

printf ( "closing files\n" );

  /* Close the fasta commands file. */
  fprintf ( erase.data, "rm %s\n", cmds.name );
  fclose ( cmds.data );

  /* Set up TLC search files. */
  tlc_main ( &erase, &names );

printf ( "after tlc_main\n" );

  /* Close the searches list file. */
  fclose ( sub_list.data );

  /* Close the Searches erase file. */
  fprintf ( sub_erase.data, "rm %s\n", sub_list_name ); 
/*  fprintf ( sub_erase.data, "rm %s\n", sub_erase.name ); */
  fclose ( sub_erase.data );

  /* Close the erase file. */
  fprintf ( erase.data, "rm -r %s\n", sub_name );
  fprintf ( erase.data, "rm %s\n", erase.name );
  fclose ( erase.data );

  /* Execute the search commands. */
  strcpy ( scr_name, "sh < " );
  d_strcat ( scr_name, cmds.name );
  d_system ( scr_name );

  /* Change to the Searches subdirectory. */
  strcpy ( scr_name, "cd " );
  d_strcat ( scr_name, sub_name );
  d_system ( scr_name );

  /* Sort the SCAN input file. */
  strcpy ( scr_name, "sort " );
  d_strcat ( scr_name, sub_list_name );
  d_strcat ( scr_name, " > " );
  d_strcat ( scr_name, sub_list_name );
  d_strcat ( scr_name, "t" );
  d_system ( scr_name );				/* 'sort clone.lis > clone.list' */

  /* Call the SCAN program. */
  strcpy ( scr_name, "scan " );
  d_strcat ( scr_name, sub_list_name );
  d_system ( scr_name );

  /* Copy the SCAN .Results file to the parent directory. */
  d_system ( "cp *.Results .." );

  /* Change to the parent directory. */
  d_system ( "cd .." );

  printf ( "\nEnd of Quick_Search program.\n" );
}  /* main */


/******************************************************************************/
/* This function prints the Copyright notice. */
copyright ()
{

  printf ( "Copyright (c) 1995-1997 The Regents of the University of California\n" );
  printf ( "\n" );
  printf ( "NOTICE: The Government is granted for itself and others acting on its behalf a\n" );
  printf ( "paid-up, non-exclusive, irrevocable worldwide license in this data to reproduce,\n" );
  printf ( "prepare derivative works, and perform publicly and display publicly.  Beginning\n" );
  printf ( "five (5) years after 4/20/1997, subject to two possible five year renewals, the\n" );
  printf ( "Government is granted for itself and others acting on its behalf a paid-up, non-\n" );
  printf ( "exclusive, irrevocable worldwide license in this data to reproduce, prepare\n" );
  printf ( "derivative works, distribute copies to the public, perform publicly and display\n" );
  printf ( "publicly, and to permit others to do so.  NEITHER THE UNITED STATES NOR THE UNITED\n" );
  printf ( "STATES DEPARTMENT OF ENERGY, NOR ANY OF THEIR EMPLOYEES, MAKES ANY WARRANTY, EXPRESS\n" );
  printf ( "OR IMPLIED, OR ASSUMES ANY LEGAL LIABILITY OR RESPONSIBILITY FOR THE ACCURACY,\n" );
  printf ( "COMPLETENESS, OR USEFULNESS OF ANY INFORMATION, APPARATUS, PRODUCT, OR PROCESS\n" );
  printf ( "DISCLOSED, OR REPRESENTS THAT ITS USE WOULD NOT INFRINGE PRIVATELY OWNED RIGHTS.\n" );
  printf ( "\n" );
  printf ( "\n" );
}  /* copyright */


/******************************************************************************/
/* This function sets up the BLAST search files. */
blast_main ( program_index, database_index, cmds, erase, names, sub_name, sub_list, sub_erase )
int     program_index;		/* index of current blast program */
int     database_index;		/* index of current database to search */
t_text  *cmds;			/* Unix shell commands */
t_text  *erase;			/* Unix erase shell commands */
t_text  *names;			/* file of sequence names file */
char    sub_name [];		/* name of subdirectory to write searches to */
t_text  *sub_list;		/* list of search output files */
t_text  *sub_erase;		/* erase commands for search output files */
{
  long    end;			/* end of DNA sequence segment */
  t_text  in;			/* input DNA sequence file */
  int     index;		/* commands files index */
  char    segment_name [ MAX_LINE ];	/* current DNA segment name */
  t_seq   seq;         		/* DNA sequence */
  long    start;		/* start of DNA sequence segment */
  int     version;     		/* DNA segment number */
  FILE    *fopen ();		/* file open function */


  /* Open the file of file names for reading. */
  open_text_file ( names );

  /* Process the sequences. */
  while ( (*names).eof != TRUE )
  {
    /* Open the sequence output file. */
    strcpy ( in.name, (*names).line );
    in.name [ stridx ( in.name, "\n" ) ] = '\0';

    /* Open the DNA sequence file for reading. */
    open_text_file ( &in );

    /* Read in the DNA sequence. */
    read_DNA_seq ( &in, &seq );
    fclose ( in.data );

    version = 1;
    start = 0;
    end = 999;
    (*names).line [ stridx ( (*names).line, "\n" ) ] = '\0';
    strcpy ( seq.name, (*names).line );

    /* Segment the DNA sequence in blocks of 1000 bp. */
    while ( start + MIN_SEQ < seq.total )
    {
      if ( (*names).eof != TRUE ) 
      {
        /* Check for end of sequence. */
        if ( end > seq.total )  end = seq.total - 1;

        /* Compute segment name. */
        make_segment_name ( &seq, version, segment_name );

        /* Write out the DNA segment to a local file. */
        if ( ( program_index == 0 ) && ( database_index == 0 ) )
          write_DNA_segment ( &seq, start, end, segment_name, erase );

        fprintf ( (*cmds).data, "blastall -p %s -d %s -i %s -v 20 -b 20 > %s/%sB%s%s\n", 
            blast_program [ program_index ], database [ database_index ], 
            segment_name, sub_name, segment_name, database_letter [ database_index ],
            blast_suffix [ program_index ] );

        fprintf ( (*sub_list).data, "%sB%s%s\n", segment_name, database_letter [ database_index ],
            blast_suffix [ program_index ] );

        fprintf ( (*sub_erase).data, "rm %sB%s%s\n", segment_name, database_letter [ database_index ],
            blast_suffix [ program_index ] );

        version++;
        if ( end == seq.total - 1 )  start = seq.total;
        else  start += 900;
        end += 900;
      }  /* if */
    }  /* while */

    /* Get the next name. */
    get_line ( names );
  }  /* while */

  fclose ( (*names).data );
}  /* blast_main */


/******************************************************************************/
/* This function sets up the FASTA search files. */
fasta_main ( database_index, fasta_cmds, erase, names, library_name, sub_name, sub_list, sub_erase )
int     database_index;		/* index of current database to search */
t_text  *fasta_cmds;		/* Unix shell commands */
t_text  *erase;			/* Unix erase shell commands */
t_text  *names;			/* file of sequence names file */
char    library_name [];	/* name of FASTA library of input DNA sequences */
char    sub_name [];		/* name of subdirectory to write searches to */
t_text  *sub_list;		/* list of search output files */
t_text  *sub_erase;		/* erase commands for search output files */
{
  long    end;			/* end of DNA sequence segment */
  t_text  in;			/* input DNA sequence file */
  int     increment;		/* DNA segment increment size */
  int     index;		/* commands files index */
  t_seq   seq;         		/* DNA sequence */
  char    segment_name [ MAX_LINE ];	/* current DNA segment name */
  long    start;		/* start of DNA sequence segment */
  int     version;     		/* DNA segment number */
  FILE    *fopen ();		/* file open function */


  /* Open the file of file names for reading. */
  open_text_file ( names );

  /* Process the sequences. */
  while ( (*names).eof != TRUE )
  {
    /* Open the sequence output file. */
    strcpy ( in.name, (*names).line );
    in.name [ stridx ( in.name, "\n" ) ] = '\0';

    /* Open the DNA sequence file for reading. */
    open_text_file ( &in );

    /* Read in the DNA sequence. */
    read_DNA_seq ( &in, &seq );
    fclose ( in.data );

    version = 1;
    start = 0;

    /* Break up the DNA by 1000 bp for DNA databases or 1000 aa for protein databases. */
    /* With 100 bp overlap between the segments. */
    if ( database_index < PROTEIN_DATABASES )
    {
      end = 2999;
      increment = 2900;
    }  /* if */
    else
    {
      end =  999;
      increment = 900;
    }  /* else */

    (*names).line [ stridx ( (*names).line, "\n" ) ] = '\0';
    strcpy ( seq.name, (*names).line );

    /* Segment the DNA sequence in blocks of 1000 or 3000 bp. */
    while ( start + MIN_SEQ < seq.total )
    {
      if ( (*names).eof != TRUE ) 
      {
        /* Check for end of sequence. */
        if ( end > seq.total )  end = seq.total - 1;

        /* Compute segment name. */
        make_segment_name ( &seq, version, segment_name );

        if ( database_index < PROTEIN_DATABASES )

          setup_fasta_protein ( database_index, &seq, start, end, version, fasta_cmds, erase,
              sub_name, sub_list, sub_erase );

        else
        {
          /* Set up the forward strand search. */
          fprintf ( (*fasta_cmds).data, "fasta -o -b 20 -d 20 -h -m 0 -n -Q -z %s ",
              segment_name );

          if ( database_index == MAX_DATABASES )
            fprintf ( (*fasta_cmds).data, "%s ", library_name );
          else
            fprintf ( (*fasta_cmds).data, "%%%s ", database_letter [ database_index ] );

          fprintf ( (*fasta_cmds).data, "ktup 1 > %s/%sF%s\n", 
              sub_name, segment_name, database_letter [ database_index ] );

          /* Set up the Searches subdirectory input list for SCAN. */
          fprintf ( (*sub_list).data, "%sF%s\n",
              segment_name, database_letter [ database_index ] );

          /* Set up the Searches subdirectory erase command. */
          fprintf ( (*sub_erase).data, "rm %sF%s\n",
              segment_name, database_letter [ database_index ] );


          /* Set up the reverse strand search. */
          fprintf ( (*fasta_cmds).data, "fasta -o -b 20 -d 20 -h -i -m 0 -n -Q -z %s ",
              segment_name );

          if ( database_index == MAX_DATABASES )
            fprintf ( (*fasta_cmds).data, "%s ", library_name );
          else
            fprintf ( (*fasta_cmds).data, "%%%s ", database_letter [ database_index ] );

          fprintf ( (*fasta_cmds).data, "ktup 1 > %s/%sF%sr\n", 
              sub_name, segment_name, database_letter [ database_index ] );

          /* Set up the Searches subdirectory input list for SCAN. */
          fprintf ( (*sub_list).data, "%sF%sr\n",
              segment_name, database_letter [ database_index ] );

          /* Set up the Searches subdirectory erase command. */
          fprintf ( (*sub_erase).data, "rm %sF%sr\n",
              segment_name, database_letter [ database_index ] );
        }  /* else */

        version++;
        if ( end == seq.total - 1 )  start = seq.total;
        else  start += increment;
        end += increment;
      }  /* if */
    }  /* while */

    /* Get the next name. */
    get_line ( names );
  }  /* while */

  fclose ( (*names).data );
}  /* fasta_main */


/******************************************************************************/
/* This function sets up the FASTA library of DNA sequences file. */
make_fasta_library ( library, erase, names )
t_text  *library;		/* library of DNA sequences */
t_text  *erase;			/* Unix erase shell commands */
t_text  *names;			/* file of sequence names file */
{
  t_text  in;			/* input DNA sequence file */
  int     index;		/* commands files index */
  t_seq   seq;         		/* DNA sequence */
  char    segment_name [ MAX_LINE ];	/* current DNA segment name */
  int     version;     		/* DNA segment number */
  FILE    *fopen ();		/* file open function */


  /* Open the DNA library output file. */
  change_suffix ( (*names).name, "Library", (*library).name );
  (*library).data = fopen ( (*library).name, "w" );

  /* Process the sequences. */
  while ( (*names).eof != TRUE )
  {
    /* Open the sequence output file. */
    strcpy ( in.name, (*names).line );
    in.name [ stridx ( in.name, "\n" ) ] = '\0';

    /* Open the DNA sequence file for reading. */
    open_text_file ( &in );

    /* Read in the DNA sequence. */
    read_DNA_seq ( &in, &seq );
    fclose ( in.data );

    /* Write out the library name line. */
    write_fasta_name ( library, seq.name, 0, seq.total, seq.total );

    /* Write out the library DNA sequence. */
    write_DNA_seq ( &seq, 0, seq.total - 1, library );

    fclose ( (*library).data );

    /* Get the next name. */
    get_line ( names );
  }  /* while */

  /* Erase the library file being created. */
  fprintf ( (*erase).data, "rm %s\n", (*library).name );

  /* Close the file of sequence names file. */
  fclose ( (*names).data );
}  /* make_fasta_library */


/******************************************************************************/
/* This function sets up the search files for TLC Decypher II search engine. */
tlc_main ( erase, names )
t_text  *erase;		/* Unix erase shell commands */
t_text  *names;		/* file of sequence names file */
{
  char    base_name [ MAX_LINE ];	/* TLC commands base name */
  int     count = 0;			/* count of sequences */
  char    dos_name [ MAX_LINE ];	/* DOS file name */
  long    end;				/* end of DNA sequence segment */
  t_text  fasta;			/* FASTA format sequence file */
  t_text  in;				/* input DNA sequence file */
  int     index;			/* commands files index */
  t_seq   seq;         			/* DNA sequence */
  long    start;			/* start of DNA sequence segment */
  t_text  tlc [ DNA_LIBRARIES ];	/* TLC search files */
  t_text  tlc_cmds;			/* TLC Unix commands file */
  t_text  tlc_ftp;			/* TLC Unix FTP input file */
  int     version;     			/* DNA segment number */
  char    version_str [ MAX_LINE ];	/* ascii version number */
  FILE    *fopen ();			/* file open function */


  /* Open the file of file names for reading. */
  open_text_file ( names );

  /* Open the commands file. */
  strcpy ( tlc_cmds.name, "tlc.cmds" );
  tlc_cmds.data = fopen ( tlc_cmds.name, "w" );

  /* Open the commands file. */
  strcpy ( tlc_ftp.name, "tlc.ftp" );
  tlc_ftp.data = fopen ( tlc_ftp.name, "w" );

  /* Open the TLC QUERY output file. */
  strcpy ( base_name, (*names).name );
  base_name [ stridx ( base_name, "\n" ) ] = '\0';
  base_name [ stridx ( base_name, "." ) ] = '\0';
  base_name [ 6 ] = '\0';
  strcpy ( version_str, "E0" );
  for ( index = 0; index < DNA_LIBRARIES; index++ )
  {
    version_str [ 0 ] = database_letter [ index ] [ 0 ];
    strcpy ( tlc [ index ].name, base_name );
    d_strcat ( tlc [ index ].name, version_str );
    d_strcat ( tlc [ index ].name, ".TL" );
    tlc [ index ].data = fopen ( tlc [ index ].name, "w" );

    fprintf ( (*erase).data, "rm %s\n", tlc [ index ].name );

    if ( ( index == 0 ) || ( index == 1 ) || ( index == 2 ) )
      write_tlc_header ( &(tlc [ index ]), PROTEIN, base_name );
    else
      write_tlc_header ( &(tlc [ index ]), DNA, base_name );
  }  /* for */

  if ( tlc_ftp.data != NULL )
  {
    fprintf ( tlc_ftp.data, "user ricke ricke\n" );
    fprintf ( tlc_ftp.data, "prompt\n" );
    fprintf ( tlc_ftp.data, "ascii\n" );
    fprintf ( tlc_ftp.data, "cd d:\n" );
    fprintf ( tlc_ftp.data, "cd TLC\n" );
    fprintf ( tlc_ftp.data, "mkdir %s\n", base_name );
    fprintf ( tlc_ftp.data, "cd ../SEQS\n" );
    fprintf ( tlc_ftp.data, "mkdir %s\n", base_name );
    fprintf ( tlc_ftp.data, "cd %s\n", base_name );
  }  /* if */

  /* Process the sequences. */
  while ( (*names).eof != TRUE )
  {
    /* Open the sequence output file. */
    strcpy ( in.name, (*names).line );
    in.name [ stridx ( in.name, "\n" ) ] = '\0';

    /* Open the DNA sequence file for reading. */
    open_text_file ( &in );

    /* Read in the DNA sequence. */
    read_DNA_seq ( &in, &seq );
    fclose ( in.data );

    /* Open the DNA output file. */
    strcpy ( fasta.name, in.name );
    d_strcat ( fasta.name, ".Fasta" );
    fasta.data = fopen ( fasta.name, "w" );

    write_fasta_name ( &fasta, in.name, 1, seq.total, seq.total );

    /* Write out the Fasta format DNA sequence. */
    write_DNA_seq ( &seq, 0, seq.total - 1, &fasta );

    fclose ( fasta.data );
    fprintf ( (*erase).data, "rm %s\n", fasta.name );

    map_to_dos ( in.name, dos_name );
    if ( tlc_ftp.data != NULL )
      fprintf ( tlc_ftp.data, "put %s %s\n", fasta.name, dos_name );
    for ( index = 0; index < DNA_LIBRARIES; index++ )
      if ( tlc [ index ].data != NULL )
        fprintf ( tlc [ index ].data, "%s\n", dos_name );
    count++;

    if ( ( count % MAX_TLC ) == 0 )
    {
      version_str [ 1 ]++;
      if ( version_str [ 1 ] == '9' + 1 )  version_str [ 1 ] = 'A';
      fprintf ( tlc_ftp.data, "cd c:\n" );
      fprintf ( tlc_ftp.data, "cd SEARCH\n" );
      for ( index = 0; index < DNA_LIBRARIES; index++ )
      {
        fprintf ( tlc_ftp.data, "put %s\n", tlc [ index ].name );

/*      fprintf ( (*erase).data, "rm %s\n", tlc [ index ].name );
*/
        if ( index < 10 )
          fprintf ( tlc_ftp.data, "rename %s %s%d\n", tlc [ index ].name,
              tlc [ index ].name, index );
        else
          fprintf ( tlc_ftp.data, "rename %s %sC\n", tlc [ index ].name,
              tlc [ index ].name );
        if ( ( index == 0 ) || ( index == 1 ) || ( index == 2 ) )
          finish_tlc_file ( &(tlc [ index ]), PROTEIN, database [ index ], base_name );
        else
          finish_tlc_file ( &(tlc [ index ]), DNA, database [ index ], base_name );

        version_str [ 0 ] = database_letter [ index ] [ 0 ];
        strcpy ( tlc [ index ].name, base_name );
        d_strcat ( tlc [ index ].name, version_str );
        d_strcat ( tlc [ index ].name, ".TL" );
        tlc [ index ].data = fopen ( tlc [ index ].name, "w" );

        if ( ( index == 0 ) || ( index == 1 ) || ( index == 2 ) )
          write_tlc_header ( &(tlc [ index ]), PROTEIN, base_name );
        else
          write_tlc_header ( &(tlc [ index ]), DNA, base_name );
      }  /* for */

      fprintf ( tlc_ftp.data, "cd d:\n" );
      fprintf ( tlc_ftp.data, "cd SEQS\n" );
      fprintf ( tlc_ftp.data, "cd %s\n", base_name );
    }  /* if */

    /* Get the next name. */
    get_line ( names );
  }  /* while */

  if ( ( count % MAX_TLC ) != 0 )
  {
    fprintf ( tlc_ftp.data, "cd c:\n" );
    fprintf ( tlc_ftp.data, "cd SEARCH\n" );
    for ( index = 0; index < DNA_LIBRARIES; index++ )
    {
      fprintf ( tlc_ftp.data, "put %s\n", tlc [ index ].name );

/*      fprintf ( (*erase).data, "rm %s\n", tlc [ index ].name );
*/
      if ( index < 10 )
        fprintf ( tlc_ftp.data, "rename %s %s%d\n", tlc [ index ].name,
            tlc [ index ].name, index );
      else
        fprintf ( tlc_ftp.data, "rename %s %sC\n", tlc [ index ].name,
            tlc [ index ].name );
      if ( ( index == 0 ) || ( index == 1 ) || ( index == 2 ) )
        finish_tlc_file ( &(tlc [ index ]), PROTEIN, database [ index ], base_name );
      else
        finish_tlc_file ( &(tlc [ index ]), DNA, database [ index ], base_name );
    }  /* for */
  }  /* if */

  fprintf ( tlc_ftp.data, "quit\n" );

  fprintf ( (*erase).data, "rm %s\n", tlc_cmds.name );
  fprintf ( (*erase).data, "rm %s\n", tlc_ftp.name );

  fprintf ( tlc_cmds.data, "ftp -in hin < %s\n", tlc_ftp.name );

  fclose ( tlc_cmds.data );
  fclose ( tlc_ftp.data );
  fclose ( (*names).data );
}  /* tlc_main */


/******************************************************************************/
/* This function writes out a TLC file header. */
write_tlc_header ( tlc_file, search_type, subdirectory )
t_text	*tlc_file;		/* TLC output file */
int	search_type;		/* DNA or PROTEIN */
char	subdirectory [];	/* subdirectory name */
{
  if ( (*tlc_file).data == NULL )  return;

/*  fprintf ( (*tlc_file).data, "[SEARCH ID] %sC\n", (*tlc_file).name ); */
  fprintf ( (*tlc_file).data, "[COLUMNS] 135\n" );
  fprintf ( (*tlc_file).data, "[COMMENT] Test script.\n" );
  fprintf ( (*tlc_file).data, "[ALGORITHM] SW\n" );

  if ( search_type == PROTEIN )
  {
    fprintf ( (*tlc_file).data, "[MATRIX] c:\\MATRICES\\ricke2.maa\n" );
    fprintf ( (*tlc_file).data, "[SCALE FACTOR] 1\n" );
    fprintf ( (*tlc_file).data, "[OPEN PENALTY] 20\n" );
    fprintf ( (*tlc_file).data, "[EXTEND PENALTY] 4\n" );
  }
  else
  {
    fprintf ( (*tlc_file).data, "[MATRIX] c:\\MATRICES\\NUC4X4HB.MNT\n" );
    fprintf ( (*tlc_file).data, "[SCALE FACTOR] 1\n" );
    fprintf ( (*tlc_file).data, "[OPEN PENALTY] 20\n" );
    fprintf ( (*tlc_file).data, "[EXTEND PENALTY] 8\n" );
  }  /* else */

  fprintf ( (*tlc_file).data, "[QUERY FORMAT] FASTA/PEARSON\n" );
  fprintf ( (*tlc_file).data, "[QUERY TYPE] NT\n" );

  if ( search_type == PROTEIN )
    fprintf ( (*tlc_file).data, "[QUERY SEARCH] 1 2 3 -1 -2 -3\n" );
  else
    fprintf ( (*tlc_file).data, "[QUERY SEARCH] B\n" );

  fprintf ( (*tlc_file).data, "[QUERY PATH] d:\\SEQS\\%s\n", subdirectory );
  fprintf ( (*tlc_file).data, "[QUERY SET] " );
}  /* write_tlc_header */


/******************************************************************************/
/* This function writes out the end of a TLC file. */
finish_tlc_file ( tlc_file, search_type, database_name, subdirectory )
t_text	*tlc_file;		/* TLC output file */
int	search_type;		/* DNA or PROTEIN */
char	database_name [];	/* subdirectory name */
char	subdirectory [];	/* subdirectory name */
{
  if ( search_type == PROTEIN )
  {
    fprintf ( (*tlc_file).data, "[TARGET TYPE] AA\n" );
    fprintf ( (*tlc_file).data, "[TARGET FRAMES] 1\n" );
  }
  else
  {
    fprintf ( (*tlc_file).data, "[TARGET TYPE] NT\n" );
    fprintf ( (*tlc_file).data, "[TARGET FRAMES] D\n" );
  }  /* else */

  fprintf ( (*tlc_file).data, "[TARGET PATH] D:\\BINARIES\n" );
  fprintf ( (*tlc_file).data, "[TARGET SET] %s\n", database_name );
  fprintf ( (*tlc_file).data, "[RESULT PATH] d:\\TLC\\%s\n", subdirectory );
  fprintf ( (*tlc_file).data, "[MAX SCORES] 500\n" );
  fprintf ( (*tlc_file).data, "[MAX ALIGNMENTS] 500\n" );
  fclose ( (*tlc_file).data );
}  /* finish_tlc_file */


/* This function maps a Sample Sequence file name to DOS file name. */
map_to_dos ( sase_name, dos_name )
char	sase_name [];		/* Sample Sequence file name */
char	dos_name  [];		/* DOS file name */
{
  char    cosmid    [ MAX_LINE ];	/* BAC or cosmid name */
  int     index = 0;			/* array index */
  char    subclone  [ MAX_LINE ];	/* subclone name */
  char    direction [ MAX_LINE ];	/* sequence direction */
  char    to_add    [ MAX_LINE ];	/* character to add string */
  char    version   [ MAX_LINE ];	/* sequence version */
  char    method    [ MAX_LINE ];	/* method */


  /* Parse the sequence name into subcomponent parts. */
  parse_name ( sase_name, cosmid, subclone, direction, version, method );

  strcpy ( dos_name, subclone );

  d_strcat ( dos_name, direction );

  strcpy ( to_add, "1" );
  while ( version [ index ] != '\0' )
  {
    to_add [ 0 ] = version [ index ];
    index++;
  }  /* while */
  d_strcat ( dos_name, to_add );

  strcpy ( to_add, method );
  to_add [ 1 ] = '\0';
  d_strcat ( dos_name, to_add );

  d_strcat ( dos_name, cosmid );

  dos_name [ 8 ] = '\0';
  d_strcat ( dos_name, ".Seq" );
}  /* map_to_dos */


/******************************************************************************/
/* This function writes out a DNA segment. */
make_segment_name ( seq, version, segment_name )
t_seq   *seq;			/* DNA sequence */
int	version;		/* current version number */
char    segment_name [];	/* current segment name */
{
  char    version_str [ MAX_LINE ];	/* ascii version number */


  /* Set up the Fasta segment sequence file name. */
  strcpy ( segment_name, (*seq).name );
  segment_name [ stridx ( segment_name, "-" ) ] = '\0'; 
  d_strcat ( segment_name, "-" );

  itoa ( version, version_str );
  if ( version < 100 )  d_strcat ( segment_name, "0" );
  if ( version <  10 )  d_strcat ( segment_name, "0" );
  d_strcat ( segment_name, version_str );

/* Don't automatically lower case all names. */
/*  strlower ( segment_name ); */
}  /* make_segment_name */


/******************************************************************************/
/* This function writes out a DNA segment. */
write_DNA_segment ( seq, start, end, segment_name, erase )
t_seq   *seq;			/* DNA sequence */
long    start;			/* start of DNA sequence segment */
long    end;			/* end of DNA sequence segment */
char    segment_name [];	/* current DNA segment name */
t_text  *erase;			/* Unix erase shell commands */
{
  t_text  segment;			/* Fasta formated DNA segment */
  FILE    *fopen ();			/* file open function */


  /* Open the Fasta segment output file. */
  strcpy ( segment.name, segment_name );
  segment.data = fopen ( segment.name, "w" );
  if ( segment.data == NULL )
  {
    printf ( "Could not open the file '%s' for writing.\n", segment.name );
    return;
  }  /* if */

  /* Write out the Fasta name line. */
  write_fasta_name ( &segment, segment.name, 
      start + 1, (*seq).total, end - start + 1 );

  /* Write out the DNA sequence. */
  write_DNA_seq ( seq, start, end, &segment );

  /* Close the segment output file. */
  fclose ( segment.data );

  fprintf ( (*erase).data, "rm %s\n", segment.name );
}  /* write_DNA_segment */


/******************************************************************************/
/* This function sets up the Fasta searches. */
setup_fasta_protein ( database_index, seq, start, end, version, cmds, erase, sub_name, sub_list, sub_erase )
int     database_index;		/* current database index */
t_seq   *seq;			/* DNA sequence */
long    start;			/* start of DNA sequence segment */
long    end;			/* end of DNA sequence segment */
int	version;		/* current version number */
t_text	*cmds;			/* Unix commands file */
t_text  *erase;			/* Unix erase files commands file */
char    sub_name [];		/* name of subdirectory to write searches to */
t_text  *sub_list;		/* list of search output files */
t_text  *sub_erase;		/* erase commands for search output files */
{
  char    base_name [ MAX_LINE ];	/* Translated sequence filename */
  int     frame;			/* Translation frame */
  t_text  segment;			/* Fasta formated DNA segment */
  t_seq   rev_seq;			/* reverse & complemented sequence */
  long    rev_end;			/* end of reverse DNA sequence segment */
  long    rev_start;			/* start of reverse DNA sequence segment */
  char    version_str [ MAX_LINE ];	/* ascii version number */
  FILE    *fopen ();			/* file open function */

printf ( "setup_fasta_protein called\n" );

  /* Reverse & complement the DNA sequence. */
  reverse_seq ( seq, &rev_seq );
  rev_end   = (*seq).total - 1 - start;
  rev_start = (*seq).total - 1 - end;	

  /* Set up the Fasta segment sequence file name. */
  make_segment_name ( seq, version, segment.name );

  strcpy ( base_name, segment.name );

  /* Write out the three forward translation files. */
  for ( frame = 0; frame <= 2; frame++ )
  {
    strcpy ( segment.name, base_name );
    d_strcat ( segment.name, "F" );
    itoa ( frame, version_str );
    d_strcat ( segment.name, version_str );

    if ( database_index == 0 )
    {
      /* Open the Fasta segment output file. */
      segment.data = fopen ( segment.name, "w" );
      if ( segment.data == NULL )
      {
        printf ( "Could not open the file '%s' for writing.\n", segment.name );
        return;
      }  /* if */

      /* Set up Unix erase file command. */
      if ( (*erase).data != NULL )

        fprintf ( (*erase).data, "rm %s\n", segment.name );

      /* Write out the Fasta name line. */
      write_fasta_name ( &segment, segment.name, 
          start + 1, (*seq).total, end - start + 1 );

      /* Translate the DNA into amino acids. */
      translate_DNA ( seq, start, end, frame, &segment );

      /* Close the sequence file. */
      fclose ( segment.data );
    }  /* if */

    /* S = Swiss Protein database; P = PIR database; */
    /* T = GenPept database */
    fprintf ( (*cmds).data, "fasta -o -b 20 -d 20 -h -m 0 -Q -z -s blosum50 %s ",
        segment.name );
    fprintf ( (*cmds).data, "%%%s ktup 1 > %s/%sF%s\n", 
        database_letter [ database_index ], sub_name, segment.name, database_letter [ database_index ] );

    /* Set up the Searches subdirectory input list for SCAN. */
    fprintf ( (*sub_list).data, "%sF%s\n",
        segment.name, database_letter [ database_index ] );

    /* Set up the Searches subdirectory erase command. */
    fprintf ( (*sub_erase).data, "rm %sF%s\n",
        segment.name, database_letter [ database_index ] );
  }  /* for */

  /* Write out the three reverse translation files. */
  for ( frame = 0; frame <= 2; frame++ )
  {
    strcpy ( segment.name, base_name );
    d_strcat ( segment.name, "R" );
    itoa ( frame, version_str );
    d_strcat ( segment.name, version_str );

    if ( database_index == 0 )
    {
      /* Open the Fasta segment output file. */
      segment.data = fopen ( segment.name, "w" );
      if ( segment.data == NULL )
      {
        printf ( "Could not open the file '%s' for writing.\n", segment.name );
        return;
      }  /* if */

      /* Set up Unix erase file command. */
      if ( (*erase).data != NULL )

        fprintf ( (*erase).data, "rm %s\n", segment.name );

      /* Write out the Fasta name line. */
      write_fasta_name ( &segment, segment.name, 
          start + 1, (*seq).total, end - start + 1 );

      /* Translate the DNA into amino acids. */
      translate_DNA ( &rev_seq, rev_start, rev_end, frame, &segment );

      /* Close the sequence file. */
      fclose ( segment.data );
    }  /* if */

    /* S = Swiss Protein database; P = PIR database; */
    /* T = GenPept database */
    fprintf ( (*cmds).data, "fasta -o -b 20 -d 20 -h -m 0 -Q -z -s blosum50 %s ",
        segment.name );
    fprintf ( (*cmds).data, "%%%s ktup 1 > %s/%sF%s\n", 
        database_letter [ database_index ], sub_name, segment.name, database_letter [ database_index ] );

    /* Set up the Searches subdirectory input list for SCAN. */
    fprintf ( (*sub_list).data, "%sF%s\n",
        segment.name, database_letter [ database_index ] );

    /* Set up the Searches subdirectory erase command. */
    fprintf ( (*sub_erase).data, "rm %sF%s\n",
        segment.name, database_letter [ database_index ] );
  }  /* for */
}  /* setup_fasta_protein */


/******************************************************************************/
/* This function writes out a Fasta format name line. */
write_fasta_name ( out, name, first, length, size )
t_text  *out;		/* output file */
char    name [];	/* sequence name */
int	first;		/* First base of sequence segment */
int	length;		/* Length of sequence */
int	size;		/* Size of sequence segment */
{
  /* Check for NULL file. */
  if ( (*out).data == NULL )  return;

  /* Pass useful information on the name line. */
  fprintf ( (*out).data, ">%s ",           name );
  fprintf ( (*out).data, "  %s ",          name );
  fprintf ( (*out).data, " First= %d, ",   first );
  fprintf ( (*out).data, " Length= %d, ",  length );
  fprintf ( (*out).data, " Size= %d ..\n", size );
}  /* write_fasta_name */


/******************************************************************************/
/* This function writes out a e-mail message in a file. */
write_email ( database, method, seq, start, end, version, email, cmds, erase )
char	database [];	/* database name to search */
char	method [];	/* search method command string */
t_seq   *seq;		/* DNA sequence */
long    start;		/* start of DNA sequence segment */
long    end;		/* end of DNA sequence segment */
int	version;	/* current version number */
t_text  *email;		/* e-mail message file */
t_text	*cmds;		/* Unix e-mail message send commands file */
t_text  *erase;		/* Unix remove e-mail message file commands file */
{
  char    email_name [ MAX_LINE ];	/* e-mail message output file name */
  char    version_str [ MAX_LINE ];	/* ascii version number */
  FILE    *fopen ();			/* file open function */


  /* Set up the e-mail message sequence file name. */
  strcpy ( email_name, (*email).name );
  email_name [ stridx ( email_name, "-" ) ] = '\0'; 
  d_strcat ( email_name, "-" );

  /* Identify the search method and database. */
  version_str [ 0 ] = method [ 7 ];
  version_str [ 1 ] = database [ 0 ];
  version_str [ 2 ] = '\0';
  d_strcat ( email_name, version_str );

  itoa   ( version, version_str );
  if ( version < 100 )  d_strcat ( email_name, "0" );
  if ( version < 10 )  d_strcat ( email_name, "0" );
  d_strcat ( email_name, version_str );

/* Don't automatically lower case names. */
/*  strlower ( email_name ); */

  /* Open the e-mail output file. */
  (*email).data = fopen ( email_name, "w" );
  if ( (*email).data == NULL )
  {
    printf ( "Could not open the file '%s' for writing.\n", email_name );
    return;
  }  /* if */

  /* Set up Unix e-mail send command. */
  if ( (*cmds).data != NULL )

    fprintf ( (*cmds).data, "mail Q@ORNL.GOV < %s\n", 
        email_name );

  /* Set up Unix erase file command. */
  if ( (*erase).data != NULL )

    fprintf ( (*erase).data, "rm %s\n", email_name );

  /* Identify the DNA type for target database. */
  if ( strcmp ( database, "SwissProt" ) == 0 )
    fprintf ( (*email).data, "TYPE DNA6\n" );
  else
    fprintf ( (*email).data, "TYPE DNA\n" ); 

  /* Identify the target database. */
  fprintf ( (*email).data, "TARGET %s\n", database );

  /* Identify the search method. */
  fprintf ( (*email).data, "%s\n", method );

  /* Pass useful information on the comment line. */
  fprintf ( (*email).data, "COMMENT %s ", email_name );
  fprintf ( (*email).data, " /First= %d, ", start + 1 );
  fprintf ( (*email).data, " /Length= %d, ", (*seq).total );
  fprintf ( (*email).data, " /Size= %d\n", end - start + 1 );

  /* Identify the following lines as DNA sequence. */
  fprintf ( (*email).data, "SEQ\n" );

  /* Write out the DNA sequence. */
  write_DNA_seq ( seq, start, end, email );

  /* Identify the end of the sequence/message. */
  fprintf ( (*email).data, "END\n" );

  /* Close the e-mail message output file. */
  fclose ( (*email).data );
}  /* write_email */


/******************************************************************************/
/* This function capitalizes a string. */
capitalize ( s )
char s [];		/* string */
{
  int  i = 0;

  while ( ( s [ i ] != '\0' ) && ( i < MAX_LINE ) )
  {
    if ( ( s [ i ] >= 'a' ) && ( s [ i ] <= 'z' ) )

      s [ i ] = s [ i ] - 'a' + 'A';

    i++;
  }  /* while */
}  /* capitalize */


/******************************************************************************/
/* This function gets the next text character. */
get_char ( text )
t_text  *text;		/* ASCII text file */
{
  if ( (*text).next == (char) EOF )  return; 
  (*text).next = ' ';

  /* Get the next sequence character. */
  if ( ( (*text).line [ (*text).line_index ] != '\n' ) &&
       ( (*text).line [ (*text).line_index ] != '\0' ) )

    (*text).next = (*text).line [ (*text).line_index++ ];

  /* skip white space */
  while ( ( ( (*text).next == ' '  ) ||
            ( (*text).next == '\n' ) ||
            ( (*text).next == '\t' ) ) && ( (*text).next != (char) EOF ) )

    if ( ( (*text).next == '\n' ) || ( (*text).next == '\0' ) )
    {
      if ( (*text).eof == TRUE )  (*text).next = (char) EOF;
      else  get_line ( text );
    }
    else
      (*text).next = (*text).line [ (*text).line_index++ ];

}  /* get_char */


/******************************************************************************/
/* This function gets the next integer from the current line. */
int  get_int ( text )
t_text  *text;		/* ASCII text file */
{
  char  c;
  int   i, sign = 1;


  /* Get the first character. */
  get_char ( text );

  /* Check for a sign. */
  if ( ( (*text).next == '+' ) || ( (*text).next == '-' ) )
  {
    sign = ( (*text).next == '+' ) ? 1 : -1;

    (*text).next = (*text).line [ (*text).line_index++ ];
  }  /* if */

  /* Traverse the integer. */
  for ( i = 0; ( (*text).next >= '0' && (*text).next <= '9' );
      ( (*text).next = (*text).line [ (*text).line_index++ ] ) )

    i = i * 10 + (*text).next - '0';

  /* Set the integer sign. */
  i *= sign;

  return ( i );  /* return the integer */
}  /* get_int */


/******************************************************************************/
/* This function gets the next text line. */
get_line ( text )
t_text  *text;		/* ASCII text file */
{
  int  c = 0, i = 0;


  if ( (*text).next == (char) EOF )  return;

  (*text).line_index = 0;

  /* Get the text line. */
  while ( ( i < MAX_LINE ) && ( ( c = getc ( (*text).data ) ) != (char) EOF ) &&
          ( c != '\n' ) )

    (*text).line [ i++ ] = c;

  /* Properly terminate the text line. */
  (*text).line [ i++ ] = '\n';
  (*text).line [ i   ] = '\0';

  /* Check for end of file. */
  if ( c == (char) EOF )  (*text).eof = TRUE;

  /* Get the first character. */
  (*text).next = (*text).line [ (*text).line_index++ ];
}  /* get_line */


/******************************************************************************/
/* This function gets the next text token. */
get_token ( text )
t_text  *text;		/* ASCII text file */
{
  int  i = 0;


  /* skip white space */
  while ( ( ( (*text).next == ' '  ) ||
            ( (*text).next == '\n' ) ||
            ( (*text).next == '\t' ) ) && ( (*text).eof != TRUE ) )
  {
    if ( (*text).next == '\n' )  get_line ( text );
    else
      (*text).next = (*text).line [ (*text).line_index++ ];
  }  /* while */

  strcpy ( (*text).token, "" );
  if ( (*text).eof == TRUE )  return;

  /* Copy the token. */
  while ( ( ( (*text).next >= '0' ) && ( (*text).next <= '9' ) ) ||
          ( ( (*text).next >= 'a' ) && ( (*text).next <= 'z' ) ) ||
          ( ( (*text).next >= 'A' ) && ( (*text).next <= 'Z' ) ) ) 
  {
    (*text).token [ i++ ] = (*text).next;

    (*text).next = (*text).line [ (*text).line_index++ ];
  }  /* while */

  /* Check for non-alphanumeric. */
  if ( i == 0 )
  {
    (*text).token [ i++ ] = (*text).next;

    (*text).next = (*text).line [ (*text).line_index++ ];
  }  /* if */

  (*text).token [ i ] = '\0';
}  /* get_token */


/******************************************************************************/
/* Convert n to characters in s. */
itoa (n, s)
char s[];
int n;
{
  int i, sign;

  if ((sign = n) < 0)  /* record sign */
    n = -n;

  /* Generate the digits in reverse order. */
  i = 0;
  do 
  {
    s[i++] = n % 10 + '0';	/* get next digit */
  }
  while ((n /= 10) > 0);	/* delete it */

  if (sign < 0)  s[i++] = '-';

  s[i] ='\0';

  reverse (s);
}  /* itoa */


/******************************************************************************/
/* Convert c to lower case; ASCII only */
lower (c)
int c;
{
  if (c >= 'A' && c <= 'Z')

    return ( c + 'a' - 'A' );

  else

    return (c);
}  /* lower */


/* This function capitalizes a string. */
strlower ( s )
char s [];		/* string */
{
  int  i = 0;


  while ( ( s [ i ] != '\0' ) && ( i < MAX_LINE ) )
  {
    s [ i ] = lower ( s [ i ] );
    i++;
  }  /* while */
}  /* strlower */


/******************************************************************************/
/* This function opens a file. */
open_text_file ( text )
t_text  *text;		/* ASCII text file */
{
  FILE  *fopen ();


  /* Initialization. */
  (*text).next = ' ';
  (*text).token [ 0 ] = '\0';
  (*text).line  [ 0 ] = '\0';
  (*text).eof         = TRUE;
  (*text).data        = NULL;

  /* Check for a valid file name. */
  if ( (*text).name [ 0 ] == '\0' )  return;

  /* Open the text file in read mode. */
  if ( ( (*text).data = fopen ( (*text).name, "r" ) ) == NULL )

    printf ( "Could not open '%s'\n", (*text).name );
  else
    (*text).eof = FALSE;

  /* Get the first text line. */
  get_line ( text );
}  /* open_text_file */


/******************************************************************************/
/* This function promts for a file name. */
prompt_file ( text, prompt )
t_text  *text;		/* ASCII text file */
char    prompt [];	/* request prompt */
{
  (*text).name [ 0 ] = '\0';
  (*text).eof = TRUE;

  /* Prompt for a valid file name. */
  while ( ( (*text).eof == TRUE ) && ( strcmp ( (*text).name, "exit" ) != 0 ) )
  {
    printf ( "%s or 'exit' ", prompt );

    scanf ( "%s", (*text).name );

    if ( strcmp ( (*text).name, "exit" ) != 0 )

      open_text_file ( text );
  }  /* while */

  printf ( "\n" );
}  /* prompt_file */


/******************************************************************************/
/* This function reads in a DNA sequence. */
read_DNA_seq ( text, seq )
t_text	*text;		/* ASCII text file */
t_seq	*seq;		/* DNA sequence */
{
  int  count;		/* composition count */
  int  composition [ MAX_ASCII ];	/* composition array */
  int  DNA_composition;			/* A,C,G,T on current line */
  int  end_of_file = FALSE;		/* end of file flag */
  int  index;


  /* Find the beginning of the DNA sequence. */
  do
  {
    /* Initialization. */
    for ( index = 0; index < MAX_ASCII; index++ )

      composition [ index ] = 0;

    count = 0;

    /* Total the line composition. */
    for ( index = 0; ( (*text).line [ index ] != '\n' ) &&
                     ( (*text).line [ index ] != '\0' ) &&
                     ( (*text).line [ index ] != (char) EOF ); index ++ )
    {
      composition [ (*text).line [ index ] ]++;

      /* Count the non-blank characters. */
      if ( ( (*text).line [ index ] != ' ' ) &&
           ( (*text).line [ index ] != '\t' ) )  count++;
    }  /* for */

    DNA_composition = composition [ 'A' ] + composition [ 'a' ] +
                      composition [ 'C' ] + composition [ 'c' ] +
                      composition [ 'G' ] + composition [ 'g' ] +
                      composition [ 'T' ] + composition [ 't' ] +
                      composition [ 'N' ] + composition [ 'n' ] +
                      composition [ 'R' ] + composition [ 'r' ] +
                      composition [ 'Y' ] + composition [ 'y' ] +
                      composition [ 'B' ] + composition [ 'b' ];

    if ( DNA_composition * 1.0 <= count * 0.75 )

      get_line ( text );	/* get the next text line */
  }
  while ( ( (*text).eof != TRUE ) &&
          ( DNA_composition * 1.0 <= count * 0.75 ) );

  /* Read in the DNA sequence. */
  (*seq).total = 0;

  do
  {
    if ( ( ( (*text).next >= 'a' ) && ( (*text).next <= 'z' ) ) ||
         ( ( (*text).next >= 'A' ) && ( (*text).next <= 'Z' ) ) ||
           ( (*text).next == '.' ) || ( (*text).next == '-' ) )
    {
      (*seq).base [ (*seq).total++ ] = (*text).next;

      if ( (*seq).total == MAX_BASES - 1 )
        printf ( "Maximum number of sequence bases reached.\n" );
    }  /* if */

    get_char ( text );		/* get the next character */

    if ( ( (*text).eof == TRUE ) && 
         ( ( (*text).next == '\n' ) || ( (*text).next == '\0' ) ||
           ( (*text).next == (char) EOF ) ) )
      end_of_file = TRUE;
  }  
  while ( ( end_of_file != TRUE ) && ( (*seq).total < MAX_BASES ) );

  /* Pad the end of the sequence with two N's for translation. */
  if ( (*seq).total + 2 < MAX_BASES )
  {
    (*seq).base [ (*seq).total ] = 'N';
    (*seq).base [ (*seq).total + 1 ] = 'N';
  }  /* if */
}  /* read_DNA_seq */


/******************************************************************************/
/* Reverse string s in place. */
reverse(s)
char s[];
{
  int  c, i, j;

  for (i = 0, j = strlen(s)-1; i < j; i++, j--)
  {
    c    = s[i];
    s[i] = s[j];
    s[j] = c;
  }  /* for */
}  /* reverse */


/******************************************************************************/
/* This function concatenates t to the end of s. */
d_strcat (s, t)
char  s[], t[];		/* s must be big enough */
{
  int  i = 0, j = 0;


  /* Find the end of s. */
  while ( s [ i ] != '\0' )  i++;

  /* Copy t. */
  while ( ( s [ i++ ] = t [ j++ ] ) != '\0' )  
    ;
}  /* d_strcat */


/******************************************************************************/
/* Return <0 if s<t, 0 if s==t, >0 if s>t */
strcmp (s, t)
char *s, *t;
{
  for ( ; *s == *t; s++, t++)

    if (*s == '\0')  return (0);

  return (*s - *t);
}  /* strcmp */


/******************************************************************************/
/* Copy t to s */
strcpy (s, t)
char *s, *t;
{
  while (*s++ = *t++)  ;
}  /* strcpy */


/******************************************************************************/
/* This function returns the index of t in s or index of '\0'. */
stridx (s, t)
char s[], t[];
{
  int  i, j, k;

  for (i = 0; s [ i ] != '\0'; i++ )
  {
    for ( j = i, k = 0; t [ k ] != '\0' && s [ j ] == t [ k ]; j++, k++ )  ;

    if ( t [ k ] == '\0' )  return ( i );
  }  /* for */

  return ( i );
}  /* stridx */


/******************************************************************************/
/* Return length of string s */
strlen (s)
char *s;
{
  char *p = s;

  while (*p != '\0')  p++;

  return (p-s);
}  /* strlen */


/******************************************************************************/
/* This function writes out a DNA sequence block. */
write_DNA_seq ( seq, first, last, text )
t_seq	*seq;		/* DNA sequence */
long	first;		/* first base of block */
long	last;		/* last base of block */
t_text  *text;		/* output text file */
{
  int   flag;
  long  index;		/* sequence index */


  /* Check for NULL output file. */
  if ( (*text).data == NULL )  return;
  
  /* Print out the DNA block. */
  for ( index = first; index <= last; index++ )
  {
    fprintf ( (*text).data, "%c", (*seq).base [ index ] );
    flag = 1;

    if ( ( ( index - first + 1 ) % 50 ) == 0 )
    {
      fprintf ( (*text).data, "\n" );

      flag = 0;
    }  /* if */
  }  /* for */

  if ( flag == 1 )

    fprintf ( (*text).data, "\n" );
}  /* write_DNA_seq */


/******************************************************************************/
/* This function translates a codon into an amino acid. */
char map_codon ( codon )
char codon [];		/* DNA codon */
{
  char amino_acid;	/* translated amino acid */
  int  index;		/* codon table index */


  capitalize ( codon );

  index = base_map   [ codon [ 0 ] ] * 16 +
          base_map   [ codon [ 1 ] ] *  4 +
          base_map_3 [ codon [ 2 ] ];

  if ( index >= MAX_CODON )
  {
    index = base_map [ codon [ 0 ] ] * 16 +
            base_map [ codon [ 1 ] ] *  4;

    /* TRA */
    if ( ( codon [ 0 ] == 'T' ) && ( codon [ 1 ] == 'R' ) &&
         ( codon [ 2 ] == 'A' ) )  return ( '*' );

    /* YTR */
    if ( ( codon [ 0 ] == 'Y' ) && ( codon [ 1 ] == 'T' ) )

      if ( ( codon [ 2 ] == 'R' ) || ( codon [ 2 ] == 'A' ) ||
           ( codon [ 2 ] == 'G' ) )  return ( 'L' );

    /* MGR */
    if ( ( codon [ 0 ] == 'M' ) && ( codon [ 1 ] == 'G' ) )

      if ( ( codon [ 2 ] == 'R' ) || ( codon [ 2 ] == 'A' ) ||
           ( codon [ 2 ] == 'G' ) )  return ( 'R' );

    if ( index >= MAX_CODON )  return ( 'X' );

    amino_acid = codon_map [ index ];

    /* GCN, GGN, CCN, ACN, & GTN */
    if ( ( amino_acid == 'A' ) || ( amino_acid == 'G' ) || 
         ( amino_acid == 'P' ) ||
         ( amino_acid == 'T' ) || ( amino_acid == 'V' ) )
      return ( amino_acid );

    /* CTN */
    if ( ( amino_acid == 'L' ) && ( codon [ 0 ] == 'C' ) )
      return ( amino_acid );

    /* CGN */
    if ( ( amino_acid == 'R' ) && ( codon [ 0 ] == 'C' ) )
      return ( amino_acid );

    /* TCN */
    if ( ( amino_acid == 'S' ) && ( codon [ 0 ] == 'T' ) )
      return ( amino_acid );

    /* ATH */
    if ( ( amino_acid == 'I' ) && ( ( codon [ 2 ] == 'H' ) ||
         ( codon [ 2 ] == 'K' ) || ( codon [ 2 ] == 'W' ) ) )
      return ( amino_acid );
 
    return ( 'X' );
  }
  else
    return ( codon_map [ index ] );
}  /* map_codon */


/******************************************************************************/
/* This function reverses and complements a DNA sequence. */
reverse_seq ( seq, rev )
t_seq	*seq;		/* DNA sequence */
t_seq	*rev;		/* reversed & complemented DNA sequence */
{
  int  index;		/* base index */


  (*rev).total = (*seq).total;

  strcpy ( (*rev).name, (*seq).name );

  for ( index = 0; index < (*seq).total; index++ )

    (*rev).base [ (*rev).total - index - 1 ] = 
      complement [ (*seq).base [ index ] ];
}  /* reverse_seq */


/******************************************************************************/
/* This function maps a DNA sequence range. */
translate_DNA ( seq, start, end, frame, text )
t_seq   *seq;		/* DNA sequence */
int	start;		/* start of DNA segment */
int	end;		/* end of DNA segment */		/* ### */
int     frame;		/* translation frame [0, 1, 2] */
t_text  *text;		/* output text file */
{
  long  block;		/* end of sequence block */
  long  index;		/* sequence index */


  /* Map the DNA sequence range. */
  index = start + frame;
  while ( index <= end )
  {
    /* Process one block of sequence at a time. */
    block = index + BLOCK_SIZE - 1;

    if ( block >= (*seq).total )  block = (*seq).total - 1;

    /* Write out the DNA translation. */
    map_seq ( seq, index, block, 'F', text, index );

    index += BLOCK_SIZE;
  }  /* while */
}  /* translate_DNA */


/******************************************************************************/
/* This function writes out the DNA translation. */
map_seq ( seq, first, last, strand, text, start )
t_seq	*seq;		/* DNA sequence */
long	first;		/* first base of block */
long	last;		/* last base of block */
char    strand;		/* F = forward; R = reverse */
t_text	*text;		/* output text file */
int	start;		/* start of DNA segment */
{
  char  amino_acid;			/* translated amino acid */
  char  codon [ CODON_SIZE + 1 ];	/* DNA codon */
  long  index;				/* sequence index */


  /* Initialization. */
  codon [ CODON_SIZE ] = '\0';

  /* Check for forward reading frame. */
  if ( strand == 'F' )
  {
    /* Translate the reading frame. */
    for ( index = first; index <= last; index += 3 )
    {
      if ( index + 2 < MAX_BASES )  
        amino_acid = map_codon ( &((*seq).base [ index ]) );
      else  amino_acid = 'X';

      /* Fasta doesn't tolerate protein sequences with '*'. */
      if ( ( index + 2 < (*seq).total ) || 
           ( ( index + 2 >= (*seq).total ) && ( amino_acid != 'X' ) ) )

        fprintf ( (*text).data, "%c", amino_acid );
    }  /* for */

    fprintf ( (*text).data, "\n" );
  }  /* if */
  else
  {
    /* Translate the complement reading frame. */
    for ( index = last; index >= first; index -= 3 )
    {
      codon [ 0 ] = complement [ (*seq).base [ index ] ];

      if ( index - 1 >= 0 )
        codon [ 1 ] = complement [ (*seq).base [ index - 1 ] ];
      else
        codon [ 1 ] = 'N';

      if ( index - 2 >= 0 )
        codon [ 2 ] = complement [ (*seq).base [ index - 2 ] ];
      else
        codon [ 2 ] = 'N';

      amino_acid = map_codon ( codon );

      if ( ( index > 1 ) || 
           ( ( index <= 1 ) && ( amino_acid != 'X' ) ) )

        fprintf ( (*text).data, "%c", amino_acid );
    }  /* for */

    fprintf ( (*text).data, "\n" );
  }  /* else */
}  /* map_seq */


/******************************************************************************/
/* This function parses a standard name. */
parse_name ( name, cosmid, subclone, direction, version, method )
char	name      [];		/* sequence name */
char	cosmid    [];		/* BAC or cosmid name */
char	subclone  [];		/* subclone number */
char    direction [];		/* sequence direction */
char	version   [];		/* sequence version */
char	method    [];		/* sequencing method */
{
  int  index;			/* array index */
  int  name_index;		/* name index */
  char sub_name [ MAX_LINE ];	/* name subcomponent */


  /* Initialize subcomponent names. */
  strcpy ( cosmid,   "" );
  strcpy ( subclone, "" );
  strcpy ( direction, "" );
  strcpy ( version,  "" );
  strcpy ( method,   "" );

  /* Extract the BAC or cosmid name. */
  strcpy ( sub_name, name );
  name_index = stridx ( sub_name, "." );
  sub_name [ name_index ] = '\0';
  strcpy ( cosmid, sub_name );

  /* Extract the subclone name. */
  name_index++;
  if ( name_index >= strlen ( name ) )  return;
  strcpy ( sub_name, &(name [ name_index ]) );
  index = stridx ( sub_name, "." );
  sub_name [ index ] = '\0';
  strcpy ( subclone, sub_name );

  /* Extract the direction. */
  name_index += index + 1;
  if ( name_index >= strlen ( name ) )  return;
  strcpy ( sub_name, &(name [ name_index ]) );
  index = stridx ( sub_name, "." );
  sub_name [ index ] = '\0';
  strcpy ( direction, sub_name );

  /* Extract the version. */
  name_index += index + 1;
  if ( name_index >= strlen ( name ) )  return;
  strcpy ( sub_name, &(name [ name_index ]) );
  index = stridx ( sub_name, "." );
  sub_name [ index ] = '\0';
  strcpy ( version, sub_name );

  /* Extract the method. */
  name_index += index + 1;
  if ( name_index >= strlen ( name ) )  return;
  strcpy ( sub_name, &(name [ name_index ]) );
  index = stridx ( sub_name, "." );
  sub_name [ index ] = '\0';
  strcpy ( method, sub_name );
}  /* parse_name */


/******************************************************************************/
/* This is function "system" from page 229 of the book "The Unix Programming Environment". */
d_system ( command )
char  *command;		/* command to execute */
{
  int  status, pid, w, tty;
  int (*istat)(), (*qstat)();

  printf ( "system: %s\n", command ); 

  status = 0;
  fflush ( stdout );
  tty = open ( "/dev/tty", 2 );
  if ( tty == -1 )
  {
    printf ( "*WARNING* Could not open '/dev/tty'\n" );
    return -1;
  }  /* if */

  if ((pid = fork ()) == 0 )
  {
    close ( 0 );  dup ( tty );
    close ( 1 );  dup ( tty );
    close ( 2 );  dup ( tty );
    close ( tty );
    execlp ( "sh", "sh", "-c", command, (char *) 0 );
    exit ( 127 );
  }

  close ( tty );
  istat = signal ( SIGINT, SIG_IGN );
  qstat = signal ( SIGQUIT, SIG_IGN );
  while ((w = wait (&status)) != pid && w != -1)  ;

  if ( w == -1 )  status = -1;
  signal ( SIGINT, istat );
  signal ( SIGQUIT, qstat );
  return status;
}  /* d_system */


/* This function creates a new file name by appending the suffix after the first period. */
change_suffix ( list_name, suffix, new_name )
char  list_name [];		/* name of list file */
char  suffix [];		/* new suffix to append after the first period */
char  new_name [];		/* resulting name 'clone.suffix' */
{
  list_name [ stridx ( list_name, "\n" ) ] = '\0';	/* Clean up list_name */
  strcpy ( new_name, list_name );			/* Copy the clone name prefix */	
  new_name [ stridx ( new_name, "." ) ] = '\0';		/* Truncate at the first period */
  d_strcat ( new_name, "." );				/* Add the "." */	
  d_strcat ( new_name, suffix );				/* Append the suffix */	
}  /* change_suffix */
